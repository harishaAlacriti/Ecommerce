package com.alacriti.ecommerce.bo.impl;

import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.alacriti.ecommerce.bo.FilterBO;
import com.alacriti.ecommerce.dao.FilterDatabase;
import com.alacriti.ecommerce.vo.PaginationRecordID;

public class FilterBOImpl implements FilterBO{
	Logger log = Logger.getLogger(FilterBOImpl.class.getName());

	public PaginationRecordID filter(int start, int end, String catogery, String search) throws ClassNotFoundException, SQLException{
		FilterDatabase filterDatabase = new FilterDatabase();
		return filterDatabase.filter(start, end, catogery, search);
	}
}
