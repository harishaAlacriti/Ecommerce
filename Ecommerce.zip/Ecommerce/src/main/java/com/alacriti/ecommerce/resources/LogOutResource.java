package com.alacriti.ecommerce.resources;

import java.net.URI;
import java.net.URISyntaxException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;

import org.apache.log4j.Logger;


@Path("/logOut")
public class LogOutResource {
	Logger log = Logger.getLogger(LogOutResource.class.getName());

	@Context HttpServletRequest request; 
	
	@GET
	public Response logOut() throws URISyntaxException{ 
		HttpSession session=request.getSession(false);
//		HttpSession session = httpServletRequest.getSession(false);
		if(session!=null){
			session.invalidate(); 
			log.info("LogOutResource.logOut: session time out");
		}
		URI uri = new URI("../index.html");
		return Response.temporaryRedirect(uri).build();
	}
}
