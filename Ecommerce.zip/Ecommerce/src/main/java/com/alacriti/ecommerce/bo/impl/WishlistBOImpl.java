package com.alacriti.ecommerce.bo.impl;

import java.sql.SQLException;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.alacriti.ecommerce.bo.WishlistBO;
import com.alacriti.ecommerce.dao.WishlistDatabase;
import com.alacriti.ecommerce.vo.ProductDetails;

public class WishlistBOImpl implements WishlistBO{
	Logger log = Logger.getLogger(WishlistBOImpl.class.getName());

	WishlistDatabase wishlistDatabase = new WishlistDatabase();
	
	public String addTowishlist(int productId, int userId) throws ClassNotFoundException, SQLException{
		return wishlistDatabase.addToWishlist(productId, userId);
	}
	
	public ArrayList<ProductDetails> showWishlist() throws ClassNotFoundException, SQLException{
		return wishlistDatabase.showWishlist();
	}
	
	public void removeFromWishlist(int productId) throws ClassNotFoundException, SQLException{
		wishlistDatabase.removeFromWishlist(productId);
	}
}
