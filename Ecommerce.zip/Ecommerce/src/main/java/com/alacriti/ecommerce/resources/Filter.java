package com.alacriti.ecommerce.resources;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.Provider;

import org.apache.log4j.Logger;

@Provider
public class Filter implements ContainerRequestFilter {
	Logger log = Logger.getLogger(Filter.class.getName());
	
	private static final CharSequence LOGIN_PATH = "login";
	private static final CharSequence REGISTERHERE_PATH = "registerHere";
	private static final CharSequence LOGINAFTERREG_PATH = "loginAfterReg";
	private static final CharSequence REGFAILURE_PATH = "regFailure";
	private static final CharSequence REGISTRATION_PATH= "registration";
	private static final CharSequence GOOGLE_PATH= "googleLogin";
	private static final CharSequence FORGOTPASSWORD_PATH= "forgotPassword";

	@Context
	HttpServletRequest httpServletRequest;
	
	public void filter(ContainerRequestContext context) throws IOException {
		log.info("Filter.filter: in filter");
		HttpSession session = httpServletRequest.getSession(false);
		
		if (context.getUriInfo().getPath().contains(GOOGLE_PATH) || context.getUriInfo().getPath().contains(LOGIN_PATH) || context.getUriInfo().getPath().contains(REGISTRATION_PATH) || context.getUriInfo().getPath().contains(LOGINAFTERREG_PATH) || context.getUriInfo().getPath().contains(REGFAILURE_PATH) || context.getUriInfo().getPath().contains(REGISTERHERE_PATH) || context.getUriInfo().getPath().contains(FORGOTPASSWORD_PATH)) {
			return;
		}
		if (session != null) {
			return;
		}
		else {
			Response forbidden = Response.status(Response.Status.FORBIDDEN)
					.entity("you are an unauthenticated user").build();
			context.abortWith(forbidden);
		}
	}
}
