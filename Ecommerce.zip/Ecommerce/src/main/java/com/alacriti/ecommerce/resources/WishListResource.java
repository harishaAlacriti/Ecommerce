package com.alacriti.ecommerce.resources;

import java.sql.SQLException;
import java.util.ArrayList;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;

import com.alacriti.ecommerce.delegate.WishlistDelegete;
import com.alacriti.ecommerce.utility.UserOpenFtl;
import com.alacriti.ecommerce.vo.ProductDetails;
import com.alacriti.ecommerce.vo.Registration;

@Path("/wishList")
public class WishListResource {
	Logger log = Logger.getLogger(WishListResource.class.getName());
	WishlistDelegete wishlistDelegete = new WishlistDelegete();
	
	
	
	@GET
	@Path("/showWishlist")
	@Produces(MediaType.APPLICATION_JSON)
	public ArrayList<ProductDetails> showWishlist() throws Exception{
		ArrayList<ProductDetails> list = wishlistDelegete.showWishlist();
		log.info("WishListResource.showWishlist: "+list);
		return list;
	}
	
	@POST
	@Path("/removeFromWishlist")
	public void removeFromWishlist(@QueryParam("productId") int productId) throws ClassNotFoundException, SQLException{
		log.info("WishListResource.removeFromWishlist: "+productId);
		wishlistDelegete.removeFromWishlist(productId);
	}
	
	
	@POST
	@Path("/{productId}")
	public String addToWishlist(@PathParam("productId") int productId) throws ClassNotFoundException, SQLException{
		Registration registration = (Registration) UserOpenFtl.profileMap.get("object");
		log.info("WishListResource.addToWishlist: "+registration.getUserId());
		int userId = registration.getUserId();
		return wishlistDelegete.addTowishlist(productId, userId);
	}
}
