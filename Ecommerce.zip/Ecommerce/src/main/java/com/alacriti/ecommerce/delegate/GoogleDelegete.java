package com.alacriti.ecommerce.delegate;

import java.util.Arrays;

import org.apache.log4j.Logger;

import com.alacriti.ecommerce.bo.impl.GoogleBOImpl;
import com.alacriti.ecommerce.resources.LoginResource;
import com.alacriti.ecommerce.utility.UserOpenFtl;
import com.alacriti.ecommerce.vo.Registration;
import com.google.api.client.googleapis.auth.oauth2.GoogleIdToken;
import com.google.api.client.googleapis.auth.oauth2.GoogleIdToken.Payload;
import com.google.api.client.googleapis.auth.oauth2.GoogleIdTokenVerifier;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.json.jackson2.JacksonFactory;


public class GoogleDelegete {
	Logger log = Logger.getLogger(GoogleDelegete.class.getName());
	
	private String tokenId;

	public GoogleDelegete(String tokenId) {
		super();
		this.tokenId = tokenId;
	}
	
	
	public String getToken() throws Exception{
		HttpTransport transport = GoogleNetHttpTransport.newTrustedTransport();
		JacksonFactory jsonFactory = JacksonFactory.getDefaultInstance();
		
		GoogleIdTokenVerifier verifier = new GoogleIdTokenVerifier.Builder(transport, jsonFactory)
	    .setAudience(Arrays.asList("803066873505-4nq90pqm3icmb0ruvrvath9h31avdrat.apps.googleusercontent.com"))
	    // If you retrieved the token on Android using the Play Services 8.3 API or newer, set
	    // the issuer to "https://accounts.google.com". Otherwise, set the issuer to
	    // "accounts.google.com". If you need to verify tokens from multiple sources, build
	    // a GoogleIdTokenVerifier for each issuer and try them both.
	    .setIssuer("accounts.google.com")
	    .build();

	// (Receive idTokenString by HTTPS POST)
		log.info("GoogleDelegete.googleLogin: token id is\n"+tokenId);
		GoogleIdToken idToken = verifier.verify(tokenId);
		if(idToken != null){
			Payload payload = idToken.getPayload();
	
			// Print user identifier
			String userId = payload.getSubject();
			log.info("GoogleDelegete.googleLogin: User ID " + userId);
	
			// Get profile information from payload
			String email = payload.getEmail();
			boolean emailVerified = Boolean.valueOf(payload.getEmailVerified());
			log.info("GoogleDelegete.googleLogin: Email verified is "+ emailVerified);
			String name = (String) payload.get("name");
			String pictureUrl = (String) payload.get("picture");
			String locale = (String) payload.get("locale");
			String familyName = (String) payload.get("family_name");
			String givenName = (String) payload.get("given_name");
		  
			Registration registration = new Registration(givenName, pictureUrl, email, 1);
			LoginResource.detailsOfLoginUser = registration;
		  
			GoogleBOImpl googleBOImpl = new GoogleBOImpl();
			Registration userDetails = googleBOImpl.googleLogin(givenName, pictureUrl, email);
					
			
				log.info("GoogleDelegete.googleLogin: "+userDetails);
				UserOpenFtl userOpenFtl = new UserOpenFtl();
				String ftlString = "";
				if(userDetails.getRole() == 1){
					ftlString = userOpenFtl.userProducts(userDetails);
				}
				else if(userDetails.getRole() == 2){
					ftlString = userOpenFtl.adminProducts(userDetails);
				}	
				return ftlString;
				// Use or store profile information
				// ...
			
		} 
		else {
			log.info("GoogleDelegete.googleLogin: Invalid ID token.");
			return "invalid Id token";
		}
	}
}
