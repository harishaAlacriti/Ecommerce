package com.alacriti.ecommerce.resources;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;

import org.apache.log4j.Logger;

import com.alacriti.ecommerce.delegate.GoogleDelegete;



@Path("/googleLogin")
public class GoogleLoginResource {
	Logger log = Logger.getLogger(GoogleLoginResource.class.getName());
	@Context HttpServletRequest request;

	@GET
//	@Path("/{Nxt_TokenId}")
	public String googlelogin(@QueryParam("Nxt_TokenId") String tokenId) throws Exception{
		log.info("GoogleLoginResource.googlelogin: This is google login\n"+tokenId);
		GoogleDelegete  googleDelegete= new GoogleDelegete(tokenId);
		log.info("GoogleLoginResource.googlelogin: This is user next page");
		HttpSession session = request.getSession(true);
		log.info("GoogleLoginResource.googlelogin: "+session);

		return googleDelegete.getToken();
		
	}
}
