package com.alacriti.ecommerce.bo;

import java.sql.SQLException;

import com.alacriti.ecommerce.vo.Registration;

public interface GoogleBO {
	public Registration googleLogin(String name, String pictureUrl, String email) throws ClassNotFoundException, SQLException;
}
