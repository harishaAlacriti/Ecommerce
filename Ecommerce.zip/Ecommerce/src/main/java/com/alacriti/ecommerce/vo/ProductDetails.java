package com.alacriti.ecommerce.vo;

import java.sql.Date;

import org.apache.log4j.Logger;

public class ProductDetails {
	Logger log = Logger.getLogger(ProductDetails.class.getName());

	
	private int id;
	private String category;
	private String productName;
	private double productPrice;
	private int quantity;
	private String description;
	private String fileName;
	private Date date;
	
	public ProductDetails() {
		super();
	}
	
	

	public ProductDetails(int id, Date date, int quantity) {
		super();
		this.id = id;
		this.quantity = quantity;
		this.date = date;
	}



	public ProductDetails(String category, String productName,
			double productPrice, int quantity, String description, String fileName) {
		super();
		this.category = category;
		this.productName = productName;
		this.productPrice = productPrice;
		this.quantity = quantity;
		this.description = description;
		this.fileName = fileName;
	}

	
	public ProductDetails(int id, String productName, int quantity, 
			double productPrice, String fileName,  String description) {
		super();
		this.id = id;
		this.productName = productName;
		this.productPrice = productPrice;
		this.quantity = quantity;
		this.description = description;
		this.fileName = fileName;
	}
	
	
	

	public ProductDetails(int id, String productName, String category, 
		 int quantity, double productPrice, String fileName, String description,
			 Date date) {
		super();
		this.id = id;
		this.category = category;
		this.productName = productName;
		this.productPrice = productPrice;
		this.quantity = quantity;
		this.description = description;
		this.fileName = fileName;
		this.date = date;
	}
	
	

	public ProductDetails(int id, String productName, int quantity, double productPrice,
			  String fileName, String description, Date date) {
		super();
		this.id = id;
		this.productName = productName;
		this.productPrice = productPrice;
		this.quantity = quantity;
		this.description = description;
		this.fileName = fileName;
		this.date = date;
	}



	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public double getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(double productPrice) {
		this.productPrice = productPrice;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}
	
	
	/*@Override
	public String toString() {
		return "ProductDetails {id:" + id + ", productName:" + productName
				+ ", productPrice:" + productPrice + ", quantity:" + quantity
				+ ", description:" + description + ", image:" + image + "}";
		
		return new StringBuffer(" id : ").append(this.id)
	
		                .append("Product Name : ").append(this.productName)
	
		                .append(" Product Price : ").append(this.productPrice).append(" Quantity : ")
	
		                .append(this.quantity).append(" Description: ").append(this.description).append(" Image : ").append(this.image).toString();

	}*/

	
}
