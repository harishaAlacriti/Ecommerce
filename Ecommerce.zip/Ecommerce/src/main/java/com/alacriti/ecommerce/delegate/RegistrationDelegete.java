package com.alacriti.ecommerce.delegate;

import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.alacriti.ecommerce.bo.impl.RegistrationBOImpl;
import com.alacriti.ecommerce.utility.ValidationUtil;
import com.alacriti.ecommerce.vo.Registration;

public class RegistrationDelegete {
	Logger log = Logger.getLogger(RegistrationDelegete.class.getName());
	RegistrationBOImpl bo =  new RegistrationBOImpl();

	private Registration registrationVO;
	
	
	public RegistrationDelegete(Registration registrationVO)
	{
		this.registrationVO = registrationVO;
	}
	
	public String registerPerson() throws Exception
	{
		ValidationUtil validationUtil = new ValidationUtil();
		if(validationUtil.validateName(registrationVO.getFirstName()) &&
				validationUtil.validateName(registrationVO.getLastName()) &&
				validationUtil.validateEmailAddress(registrationVO.getEmailId())  &&
				validationUtil.validatePhoneNumber(Long.toString(registrationVO.getMobileNumber())) &&
				validationUtil.validatePinNumber(Integer.toString(registrationVO.getPincode())) 
		){
		
			String str =null;
			
			str = bo.registerPerson(registrationVO);
			return str;
		}
		else{
			return "Enter Correct Details";
		}
	}

	public void editProfile() throws ClassNotFoundException, SQLException {
		bo.editProfile(registrationVO);
		
	}
}
