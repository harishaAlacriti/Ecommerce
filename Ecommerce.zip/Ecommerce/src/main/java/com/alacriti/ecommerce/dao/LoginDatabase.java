package com.alacriti.ecommerce.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import org.apache.log4j.Logger;

import com.alacriti.ecommerce.vo.Registration;

public class LoginDatabase extends DatabaseClass{
	final static Logger log = Logger.getLogger(LoginDatabase.class);

	public Registration login(String emailId, String password) throws Exception{
		
		log.info("LoginDatabase.login: this is database "+emailId+" and "+password);
		
		DatabaseClass databaseClass = new DatabaseClass();
		Connection con = databaseClass.getConnection();
		Statement st = con.createStatement();
		
		Registration profile1 = null;
			String q1 = "select * from user_dtls_tbl where mailid='"+emailId+"' and password='"+password+"'";
			log.info("LoginDatabase.login: "+q1);
			ResultSet set= st.executeQuery(q1);
			if(set.next()){
				log.info("LoginDatabase.login: "+set.getInt(1));
				log.info("LoginDatabase.login: "+set.getString(2));
				log.info("LoginDatabase.login: "+set.getString(3));
				profile1 = new Registration(set.getInt(1), set.getString(2), set.getString(3), set.getString(4), set.getLong(6), set.getString(7), set.getInt(8), "../ProfileImages/"+set.getString(9), set.getInt(12));
				String q2="insert into login_dtls_tbl(userid) values("+set.getInt(1)+")";
				st.executeUpdate(q2);
			}
			else{
				return null;
			}
			int userId = profile1.getUserId();
			
			String q2 = "select count(*) from cart_tbl where userid="+userId;
			ResultSet set2 = st.executeQuery(q2);
			set2.next();
			int cartCount = set2.getInt(1);
			
			
			String q3 = "select count(*) from wishlist_tbl where userid="+userId;
			ResultSet set3 = st.executeQuery(q3);
			set3.next();
			int wishlistCount = set3.getInt(1);
			
			
			profile1.setCartCount(cartCount);
			profile1.setWishlistCount(wishlistCount);
			
				closeConnection(con);
				log.info("LoginDatabase.login: "+profile1);
				return profile1;
			
	}
}
