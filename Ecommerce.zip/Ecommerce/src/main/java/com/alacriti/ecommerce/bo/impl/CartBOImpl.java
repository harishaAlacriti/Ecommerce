package com.alacriti.ecommerce.bo.impl;

import java.sql.SQLException;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.alacriti.ecommerce.bo.CartBO;
import com.alacriti.ecommerce.dao.CartDatabase;
import com.alacriti.ecommerce.vo.ProductDetails;

public class CartBOImpl implements CartBO{
	Logger log = Logger.getLogger(CartBOImpl.class.getName());

	CartDatabase cartDatabase = new CartDatabase();
	
	public String addToCart(int productId, int userId) throws ClassNotFoundException, SQLException{
		return cartDatabase.addToCart(productId, userId);
	}
	
	public ArrayList<ProductDetails> showCart() throws ClassNotFoundException, SQLException{
		return cartDatabase.showCart();
	}
	
	public ArrayList<ProductDetails> buyCartItems() throws ClassNotFoundException, SQLException{
		return cartDatabase.buyCartItems();
	}
	
	public void removefromCart(int productId) throws ClassNotFoundException, SQLException{
		cartDatabase.removefromCart(productId);
	}
}
