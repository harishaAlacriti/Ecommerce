package com.alacriti.ecommerce.utility;

import java.io.OutputStreamWriter;
import java.io.StringWriter;
import java.io.Writer;

import org.apache.log4j.Logger;

import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateExceptionHandler;

public class ProductViewFtl {
	Logger log = Logger.getLogger(ProductViewFtl.class.getName());

	public String productView() throws Exception{
		Writer consoleWriter = new OutputStreamWriter(System.out);
		StringWriter stringWriter = new StringWriter();
		
		
		try{
		FtlConfiguration ftlConfiguration = new FtlConfiguration();
		Configuration configuration = ftlConfiguration.getConfiguration();
		
		configuration.setTemplateExceptionHandler(TemplateExceptionHandler.RETHROW_HANDLER);
		Template tmp = configuration.getTemplate("productviewpage.ftl");
		
		
		consoleWriter.toString();
		tmp.process(UserOpenFtl.profileMap, consoleWriter);
	
        tmp.process(UserOpenFtl.profileMap, stringWriter);
        }catch(Exception e){
        	log.warn("ProductViewFtl.productView: "+e);
        }

        return stringWriter.toString();
		
	}
	
}
