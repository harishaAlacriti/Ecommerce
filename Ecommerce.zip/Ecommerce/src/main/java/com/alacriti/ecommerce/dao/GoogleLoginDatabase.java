package com.alacriti.ecommerce.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.apache.log4j.Logger;

import com.alacriti.ecommerce.vo.Registration;

public class GoogleLoginDatabase extends DatabaseClass{
	Logger log = Logger.getLogger(GoogleLoginDatabase.class.getName());

	
	public Registration googleLogin(String name, String pictureUrl, String email) throws ClassNotFoundException, SQLException{
		Connection con = getConnection();
		Statement st = con.createStatement();
		
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		log.info("GoogleLoginDatabase.googleLogin: "+dateFormat.format(cal.getTime()));
		
		
		String q1 = "select * from user_dtls_tbl where mailid='"+email+"'";
		ResultSet set1 = st.executeQuery(q1);
		if(!set1.next()){
			String q2 = "insert into user_dtls_tbl(firstname, mailid, image, createdon) values('"+name+"', '"+email+"', '"+pictureUrl+"', '"+dateFormat.format(cal.getTime())+"')";
			int n2 = st.executeUpdate(q2);
			log.info("GoogleLoginDatabase.googleLogin: record insertion "+n2);
			log.info("GoogleLoginDatabase.googleLogin: record inserted successfully");
		}
		else{
			log.info("GoogleLoginDatabase.googleLogin: this record is already there");
		}
		
		Registration profile1 = null;
		String q3 = "select * from user_dtls_tbl where mailid='"+email+"'";
		ResultSet set3 = st.executeQuery(q3);

		if(set3.next()){
			profile1 = new Registration(set3.getInt(1), set3.getString(2), set3.getString(3), set3.getString(4), set3.getLong(6), set3.getString(7), set3.getInt(8), set3.getString(9), set3.getInt(12));
			String q4="insert into login_dtls_tbl(userid) values("+set3.getInt(1)+")";
			st.executeUpdate(q4);
			closeConnection(con);
			return profile1;
		}
		else{
			closeConnection(con);
			return null;
		}
				
		
		
	}
	
}
