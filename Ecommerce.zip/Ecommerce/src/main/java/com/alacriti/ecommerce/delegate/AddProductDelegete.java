package com.alacriti.ecommerce.delegate;

import org.apache.log4j.Logger;

import com.alacriti.ecommerce.bo.impl.AddProductBOImpl;
import com.alacriti.ecommerce.vo.ProductDetails;

public class AddProductDelegete {
	Logger log = Logger.getLogger(AddProductDelegete.class.getName());

	private ProductDetails prodctDetails;

	public AddProductDelegete(ProductDetails prodctDetails) {
		this.prodctDetails = prodctDetails;
	}
	
	public String addProduct() throws Exception{
		AddProductBOImpl addProductBOImpl = new AddProductBOImpl();
		String str = addProductBOImpl.addProduct(prodctDetails);
		
		return str;
	}
	
	
}
