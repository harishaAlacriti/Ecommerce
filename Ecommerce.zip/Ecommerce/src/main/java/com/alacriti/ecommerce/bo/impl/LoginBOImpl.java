package com.alacriti.ecommerce.bo.impl;

import org.apache.log4j.Logger;

import com.alacriti.ecommerce.bo.LoginBO;
import com.alacriti.ecommerce.dao.LoginDatabase;
import com.alacriti.ecommerce.vo.Registration;

public class LoginBOImpl implements LoginBO{
	Logger log = Logger.getLogger(LoginBOImpl.class.getName());

	public Registration loginUser(String emailId, String password) throws Exception{
		LoginDatabase loginDatabase = new LoginDatabase();
		log.info("LoginBOImpl.loginUser: this is boimpl "+emailId+" and "+password);
		return loginDatabase.login(emailId, password);
	}
}
