package com.alacriti.ecommerce.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.UUID;

import org.apache.log4j.Logger;

import com.alacriti.ecommerce.vo.PaginationRecordID;
import com.alacriti.ecommerce.vo.ProductDetails;

public class PageDb extends DatabaseClass{
	Logger log = Logger.getLogger(PageDb.class.getName());


	public ArrayList<ProductDetails> pagination(int start, String uniqId, int offset) throws SQLException, ClassNotFoundException{
		Connection con = getConnection();
		Statement st = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
		log.info("PageDb.pagination: uid for in display method : "+ uniqId);
		
		ArrayList<ProductDetails> getList = new ArrayList<ProductDetails>();
//		String q4="select * from pagination_tbl where  record_id='"+uniqId+"' and sequence_id between "+(start)+" and "+(start+5);
		String q4 = "select * from pagination_tbl where record_id='"+uniqId+"' limit "+start+", "+offset;
		log.info("PageDb.pagination: "+q4);
		ResultSet set4 = st.executeQuery(q4);
		while(set4.next()){
			ProductDetails productDetails1 = new ProductDetails(
					set4.getInt(3),
					set4.getString(4),
					set4.getString(5),
					set4.getInt(6),
					set4.getDouble(7), 
					"../ProductImgs/"+set4.getString(8), 
					set4.getString(9), set4.getDate(10));
			getList.add(productDetails1);
		}
		log.info("PageDb.pagination: list size is: "+getList.size());
		closeConnection(con);
		return getList;
	}
	
	
	
	
	public PaginationRecordID getRecordCount(String catogery) throws SQLException, ClassNotFoundException{
		Connection con = getConnection();
		Statement st = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);

		String uniqueID = UUID.randomUUID().toString();
		
		
		String q = "select catgid from catg_tbl where catg='"+catogery+"'";
		ResultSet set = st.executeQuery(q);
		set.next();
		int catg = set.getInt(1);
	
		
	
		ArrayList<ProductDetails> setList1 = new ArrayList<ProductDetails>();
		String q1 = "select * from prod_dtls_tbl where catg="+catg+" and quantity!=0";
		log.info("PageDb.getRecordCount: "+q1);
		ResultSet set1 = st.executeQuery(q1);
		
		while(set1.next()){
			setList1.add(new ProductDetails(set1.getInt(1), set1.getString(2), catogery, set1.getInt(4), set1.getDouble(5), set1.getString(6), set1.getString(7), set1.getDate(8)));
		}
		set1.close();
		
		
		ProductDetails productDetails = new ProductDetails();
		int j = 1;
		int n3 = 0;
		for(int i=0; i<setList1.size(); i++){
			productDetails = setList1.get(i);
			String q3 = "insert into pagination_tbl values('"+uniqueID
					+"', "+j
					+", "+productDetails.getId()
					+", '"+productDetails.getProductName()
					+"', '"+productDetails.getCategory()
					+"', "+productDetails.getQuantity()
					+", "+productDetails.getProductPrice()
					+", '"+productDetails.getFileName()
					+"', '"+productDetails.getDescription()
					+"', '"+productDetails.getDate()
					+"')";
			n3 = n3 + st.executeUpdate(q3);
			j++;		
		}
		log.info("PageDb.getRecordCount: records inserted is: "+n3);
		
		int count = setList1.size();
		int offset = 6;
		set1.close();
		closeConnection(con);
		
		PaginationRecordID paginationRecordID = new PaginationRecordID(uniqueID, count, offset);
		
		return paginationRecordID;

	}
}
