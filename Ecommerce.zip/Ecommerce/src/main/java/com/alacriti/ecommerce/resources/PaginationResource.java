package com.alacriti.ecommerce.resources;

import java.sql.SQLException;
import java.util.ArrayList;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;

import com.alacriti.ecommerce.delegate.PagenationDelegete;
import com.alacriti.ecommerce.vo.PaginationRecordID;
import com.alacriti.ecommerce.vo.ProductDetails;

@Path("/pagination")

public class PaginationResource {
	Logger log = Logger.getLogger(PaginationResource.class.getName());
	PagenationDelegete agenationDelegete = new PagenationDelegete();
	
	@GET
	@Path("/pages")
	@Produces(MediaType.APPLICATION_JSON)
	public ArrayList<ProductDetails> paginationNext(@QueryParam("start") int pageNumber,
													@QueryParam("id") String uniqId,
													@QueryParam("offset") int offset) throws ClassNotFoundException, SQLException{
		log.info("PaginationResource.paginationNext: page number is"+pageNumber);
		log.info("PaginationResource.paginationNext:uniqid is"+uniqId);
		log.info("PaginationResource.paginationNext:offset is"+offset);
		
		ArrayList<ProductDetails> list =  agenationDelegete.pagination(pageNumber, uniqId, offset);
		log.info("PaginationResource.paginationNext:list size in resource is: "+list.size());
		return list;
	}
	
	@GET
	@Path("/count")
	@Produces(MediaType.APPLICATION_JSON)
	public PaginationRecordID getRecordCount(@QueryParam("catogery") String catogery) throws ClassNotFoundException, SQLException{
		return agenationDelegete.getRecordCount(catogery);
	}
	
}
