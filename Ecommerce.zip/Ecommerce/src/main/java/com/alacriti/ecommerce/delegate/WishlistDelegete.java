package com.alacriti.ecommerce.delegate;

import java.sql.SQLException;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.alacriti.ecommerce.bo.impl.WishlistBOImpl;
import com.alacriti.ecommerce.vo.ProductDetails;

public class WishlistDelegete {
	Logger log = Logger.getLogger(WishlistDelegete.class.getName());

	WishlistBOImpl wishlistBOImpl = new WishlistBOImpl();
	
	public String addTowishlist(int productId, int userId) throws ClassNotFoundException, SQLException{
		return wishlistBOImpl.addTowishlist(productId, userId);
	}
	
	public ArrayList<ProductDetails> showWishlist() throws ClassNotFoundException, SQLException{
		return wishlistBOImpl.showWishlist();
	}
	
	public void removeFromWishlist(int productId) throws ClassNotFoundException, SQLException{
		wishlistBOImpl.removeFromWishlist(productId);
	}
}
