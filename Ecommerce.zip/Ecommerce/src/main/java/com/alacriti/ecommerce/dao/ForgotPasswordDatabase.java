package com.alacriti.ecommerce.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;

public class ForgotPasswordDatabase extends DatabaseClass{
	Logger log = Logger.getLogger(ForgotPasswordDatabase.class.getName());

	public String forgotPassword(String email, String password) throws SQLException, ClassNotFoundException{
		Connection con;
			con = getConnection();
			Statement st = con.createStatement();
			
			String q1 = "select mailid from user_dtls_tbl where mailid='"+email+"'";
			ResultSet set1 = st.executeQuery(q1);
			if(set1.next()){
				String str = set1.getString(1);
				String q2 = "update user_dtls_tbl set password='"+password+"' where mailid='"+set1.getString(1)+"'";
				st.executeUpdate(q2);

				return str;
			}
			else{
				return null;
			}
		
		
	}
}
