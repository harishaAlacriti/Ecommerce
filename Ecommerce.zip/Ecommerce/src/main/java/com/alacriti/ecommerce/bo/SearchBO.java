package com.alacriti.ecommerce.bo;

import java.sql.SQLException;

import com.alacriti.ecommerce.vo.PaginationRecordID;

public interface SearchBO {
	public PaginationRecordID searchRecordCount(String search, String catogery) throws ClassNotFoundException, SQLException;
}
