package com.alacriti.ecommerce.bo.impl;

import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.alacriti.ecommerce.bo.GoogleBO;
import com.alacriti.ecommerce.dao.GoogleLoginDatabase;
import com.alacriti.ecommerce.vo.Registration;

public class GoogleBOImpl implements GoogleBO{
	Logger log = Logger.getLogger(GoogleBOImpl.class.getName());
	
	public Registration googleLogin(String name, String pictureUrl, String email) throws ClassNotFoundException, SQLException{
		GoogleLoginDatabase googleLoginDatabase = new GoogleLoginDatabase();
		Registration str = googleLoginDatabase.googleLogin(name, pictureUrl, email);
		log.info("GoogleBOImpl.googleLogin: "+str);
		return str;
	}
}
