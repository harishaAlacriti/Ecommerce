package com.alacriti.ecommerce.bo.impl;

import org.apache.log4j.Logger;

import com.alacriti.ecommerce.dao.AddProductToDatabase;
import com.alacriti.ecommerce.vo.ProductDetails;

public class AddProductBOImpl {
	Logger log = Logger.getLogger(AddProductBOImpl.class.getName());

	public String addProduct(ProductDetails prodctDetails) throws Exception{
		AddProductToDatabase addDB = new AddProductToDatabase();
		String str = addDB.addProduct(prodctDetails);
	
		return str;
	}
}
