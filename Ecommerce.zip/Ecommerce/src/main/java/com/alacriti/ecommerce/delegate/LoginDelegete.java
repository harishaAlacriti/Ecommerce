package com.alacriti.ecommerce.delegate;

import org.apache.log4j.Logger;

import com.alacriti.ecommerce.bo.impl.LoginBOImpl;
import com.alacriti.ecommerce.vo.Registration;

public class LoginDelegete {
	Logger log = Logger.getLogger(LoginDelegete.class.getName());

	private String emailId;
	private String password;
	public LoginDelegete(String emailId, String password)
	{
		this.emailId = emailId;

		this.password = password;
	}
	
	public Registration loginUser() throws Exception
	{
		log.info("LoginDelegete.loginUser: this is delegete "+emailId+" and "+password);
		LoginBOImpl loginBOImpl = new LoginBOImpl();
		return loginBOImpl.loginUser(emailId, password);
		
	}
}
