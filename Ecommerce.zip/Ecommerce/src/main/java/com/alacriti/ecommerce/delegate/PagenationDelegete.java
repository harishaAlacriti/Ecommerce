package com.alacriti.ecommerce.delegate;

import java.sql.SQLException;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.alacriti.ecommerce.bo.impl.PaginationBOImpl;
import com.alacriti.ecommerce.vo.PaginationRecordID;
import com.alacriti.ecommerce.vo.ProductDetails;

public class PagenationDelegete {
	Logger log = Logger.getLogger(PagenationDelegete.class.getName());

	PaginationBOImpl paginationBOImpl = new PaginationBOImpl();
	
	public ArrayList<ProductDetails> pagination(int pageNumber, String uniqId, int offset) throws ClassNotFoundException, SQLException{
		return paginationBOImpl.pagination(pageNumber, uniqId, offset);
	}
	
	public PaginationRecordID getRecordCount(String catogery) throws ClassNotFoundException, SQLException{
		return paginationBOImpl.getRecordCount(catogery);
	}
}
