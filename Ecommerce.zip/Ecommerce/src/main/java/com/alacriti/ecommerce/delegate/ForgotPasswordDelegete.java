package com.alacriti.ecommerce.delegate;

import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.alacriti.ecommerce.bo.impl.ForgotPasswordBOImpl;

public class ForgotPasswordDelegete {
	Logger log = Logger.getLogger(ForgotPasswordDelegete.class.getName());

	ForgotPasswordBOImpl forgotPasswordBOImpl = new ForgotPasswordBOImpl();
	public String forgotPassword(String email, String password) throws ClassNotFoundException, SQLException{
		return forgotPasswordBOImpl.forgotPassword(email, password);
	}
}
