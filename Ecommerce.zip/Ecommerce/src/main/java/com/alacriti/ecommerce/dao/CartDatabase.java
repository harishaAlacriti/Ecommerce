package com.alacriti.ecommerce.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.alacriti.ecommerce.resources.LoginResource;
import com.alacriti.ecommerce.utility.UserOpenFtl;
import com.alacriti.ecommerce.vo.ProductDetails;
import com.alacriti.ecommerce.vo.Registration;

public class CartDatabase extends DatabaseClass{
	Logger log = Logger.getLogger(CartDatabase.class.getName());
	
	public String addToCart(int productId, int userId) throws SQLException, ClassNotFoundException{
		
		Connection con = getConnection();
		Statement st = con.createStatement();
		
		String q1 = "select cartid from cart_tbl where product="+productId+" and userid="+userId;
		ResultSet set1 = st.executeQuery(q1);
		if(set1.next()){
			log.info("CartDatabase.addToCart: already have product");
			return "You already have this product in your cart";
		}
		else{
			String q2 = "insert into cart_tbl(product, userid) values("+productId+", "+userId+")";
			int n2 = st.executeUpdate(q2);
			if(n2==1){
				closeConnection(con);
				return "Product is added successfully";
			}
			else{
				closeConnection(con);
				return "Product is not added to your cart, please try again";
			}
		}
	}

	
	public ArrayList<ProductDetails> showCart() throws ClassNotFoundException, SQLException{
		Connection con = getConnection();
		Statement st = con.createStatement();
		
		String q = "select * from catg_tbl";
		ResultSet set = st.executeQuery(q);
		Map<Integer, String> catogeryMap = new HashMap<Integer, String>();
		while(set.next()){
			catogeryMap.put(set.getInt(1), set.getString(2));
		}
		
		String q1 = "select product from cart_tbl where userid="+LoginResource.detailsOfLoginUser.getUserId();
		ResultSet set1 = st.executeQuery(q1);
		ArrayList<ProductDetails> cortList = new ArrayList<ProductDetails>();
		ArrayList<Integer> prodIdList = new ArrayList<Integer>();
		while(set1.next()){
			prodIdList.add(set1.getInt(1));
		}
		
		 
		for(int i=0; i<prodIdList.size(); i++){
			String q2 = "select * from prod_dtls_tbl where prodid="+prodIdList.get(i);
			ResultSet set2 = st.executeQuery(q2);	
		
			while(set2.next()){			
				ProductDetails productDetails = new ProductDetails(set2.getInt(1), set2.getString(2), set2.getInt(4), set2.getDouble(5), "../ProductImgs/"+set2.getString(6), set2.getString(7));
				cortList.add(productDetails);
			}
		}
		closeConnection(con);
		return cortList;
	}
	
	
	public ArrayList<ProductDetails> buyCartItems() throws SQLException, ClassNotFoundException{
		Connection con = getConnection();
		Statement st = con.createStatement();
		
		String q1 = "select product from cart_tbl where userid="+LoginResource.detailsOfLoginUser.getUserId();
		ResultSet set1 = st.executeQuery(q1);
		ArrayList<Integer> productsList = new ArrayList<Integer>();
		ArrayList<ProductDetails> productDetailsList = new ArrayList<ProductDetails>();
		while(set1.next()){
			productsList.add(set1.getInt(1));
		}
		String q2 = "delete from cart_tbl where userid="+LoginResource.detailsOfLoginUser.getUserId();
		int n2 = st.executeUpdate(q2);
		log.info("CartDatabase.buyCartItems: number of records deleted from cart_tbl is "+n2);
		
		ResultSet set3 = null;
		for(int i=0; i<productsList.size(); i++){
			String q3 = "select * from prod_dtls_tbl where prodid="+productsList.get(i)+" and quantity!=0";
			set3 = st.executeQuery(q3);
			if(set3.next()){
			
				ProductDetails productDetails = new ProductDetails(set3.getInt(1), set3.getString(2), set3.getInt(4), set3.getDouble(5), "../ProductImgs/"+set3.getString(6), set3.getString(7));
				productDetailsList.add(productDetails);	
			
				String q4 = "insert into orders_tbl(userid, product, catg, quantity) values("+LoginResource.detailsOfLoginUser.getUserId()+", "+productsList.get(i)+", "+set3.getInt(3)+", 1)";
				st.executeUpdate(q4);
				
				String q5 = "update prod_dtls_tbl set quantity="+(productDetails.getQuantity()-1)+" where prodid="+productsList.get(i);
				st.executeUpdate(q5);
//				int n5 = st.executeUpdate(q5);
			}
			
		}
		if(set3!=null){
			set3.close();
		}
		
	
		closeConnection(con);
		return productDetailsList;
		
	}
	
	
	public void removefromCart(int productId) throws ClassNotFoundException, SQLException{
		Connection con = getConnection();
		Statement st = con.createStatement();
		
		Registration user = (Registration) UserOpenFtl.profileMap.get("object");
		String q1 = "delete from cart_tbl where product="+productId+" and userid="+user.getUserId();
		int n = st.executeUpdate(q1);
		closeConnection(con);
		if(n==1){
			log.info("WishlistDatabase.removeFromWishlist: record is deleted successfully");
		}
		else{
			log.info("WishlistDatabase.removeFromWishlist: record is not deleted");
		}
	}
}
