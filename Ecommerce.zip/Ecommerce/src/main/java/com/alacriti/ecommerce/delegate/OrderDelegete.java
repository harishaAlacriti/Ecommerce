package com.alacriti.ecommerce.delegate;

import java.sql.SQLException;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.alacriti.ecommerce.bo.impl.OrderBOImpl;
import com.alacriti.ecommerce.vo.ProductDetails;

public class OrderDelegete {
	Logger log = Logger.getLogger(OrderDelegete.class.getName());

	OrderBOImpl orderBOImpl = new OrderBOImpl();
	
	public String orderProduct(int productId, int quantity) throws ClassNotFoundException, SQLException{
		return orderBOImpl.orderProduct(productId, quantity);
	}
	
	public ArrayList<ProductDetails> showOrders() throws Exception{
		return orderBOImpl.showOrders();
	}
}
