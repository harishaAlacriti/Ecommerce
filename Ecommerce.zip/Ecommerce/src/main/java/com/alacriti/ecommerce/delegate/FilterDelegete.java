package com.alacriti.ecommerce.delegate;

import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.alacriti.ecommerce.bo.impl.FilterBOImpl;
import com.alacriti.ecommerce.vo.PaginationRecordID;

public class FilterDelegete {
	Logger log = Logger.getLogger(FilterDelegete.class.getName());

	public PaginationRecordID filter(int start, int end, String catogery, String search) throws ClassNotFoundException, SQLException{
		FilterBOImpl filterBOImpl = new FilterBOImpl();
		return filterBOImpl.filter(start, end, catogery, search);
	}
}
