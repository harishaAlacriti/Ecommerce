package com.alacriti.ecommerce.vo;

import org.apache.log4j.Logger;

public class PaginationRecordID {
	Logger log = Logger.getLogger(PaginationRecordID.class.getName());

	private String uniqID;
	private int recordCount;
	private int offset;
	
	public PaginationRecordID() {
		super();
	}

	public PaginationRecordID(String uniqID, int recordCount, int offset) {
		super();
		this.uniqID = uniqID;
		this.recordCount = recordCount;
		this.offset = offset;
	}

	public String getUniqID() {
		return uniqID;
	}

	public void setUniqID(String uniqID) {
		this.uniqID = uniqID;
	}

	public int getRecordCount() {
		return recordCount;
	}

	public void setRecordCount(int recordCount) {
		this.recordCount = recordCount;
	}

	public int getOffset() {
		return offset;
	}

	public void setOffset(int offset) {
		this.offset = offset;
	}
	
	
}
