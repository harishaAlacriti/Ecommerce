package com.alacriti.ecommerce.delegate;

import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.alacriti.ecommerce.bo.impl.SelectorBOImpl;
import com.alacriti.ecommerce.vo.PaginationRecordID;

public class SelectorDelegete {
	Logger log = Logger.getLogger(SelectorDelegete.class.getName());

	SelectorBOImpl selectorBOImpl = new SelectorBOImpl();
	public PaginationRecordID selectorRecordCount(String selector) throws ClassNotFoundException, SQLException{
		return selectorBOImpl.selectorRecordCount(selector);
	}
}
