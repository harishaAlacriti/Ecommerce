package com.alacriti.ecommerce.resources;

import java.sql.SQLException;
import java.util.ArrayList;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;

import com.alacriti.ecommerce.delegate.OrderDelegete;
import com.alacriti.ecommerce.vo.ProductDetails;

@Path("/order")
public class OrderResource {
	Logger log = Logger.getLogger(OrderResource.class.getName());
	OrderDelegete orderDelegete = new OrderDelegete();


	@POST
	public String orderProduct(@QueryParam("productId") int productId, @QueryParam("Quantity") int quantity) throws ClassNotFoundException, SQLException{
		log.info("product id is: "+productId);
		log.info("user id is: "+quantity);
		
		return orderDelegete.orderProduct(productId, quantity);
	}
	
	@GET
	@Path("/showOrders")
	@Produces(MediaType.APPLICATION_JSON)
	public ArrayList<ProductDetails> showOrders() throws Exception{
		ArrayList<ProductDetails> list = orderDelegete.showOrders();
		log.info("WishListResource.addToWishlist: "+list);
		return list;
	}
	
}
