package com.alacriti.ecommerce.utility;

import java.io.OutputStreamWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.alacriti.ecommerce.vo.Registration;

import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateExceptionHandler;

public class AddProductFtl {
	Logger log = Logger.getLogger(AddProductFtl.class.getName());

	public static Map<String, Object> profileMap = new HashMap<String, Object>();	
	StringWriter stringWriter = new StringWriter();
	Writer consoleWriter = new OutputStreamWriter(System.out);
	
	public String addProduct(Registration detailsOfLoginUser){
		try{
			FtlConfiguration ftlConfiguration = new FtlConfiguration();
			Configuration configuration = ftlConfiguration.getConfiguration();
			
			configuration.setTemplateExceptionHandler(TemplateExceptionHandler.RETHROW_HANDLER);
			Template tmp = configuration.getTemplate("AddProduct.ftl");
			profileMap.put("object", detailsOfLoginUser);
			
			consoleWriter.toString();
			tmp.process(profileMap, consoleWriter);
		
	        tmp.process(profileMap, stringWriter);
        }catch(Exception e){
        	log.warn("AddProductFtl.addProduct: "+e);
        }

        return stringWriter.toString();
		
	}

}
