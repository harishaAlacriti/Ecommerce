package com.alacriti.ecommerce.bo.impl;

import java.sql.SQLException;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.alacriti.ecommerce.bo.OrderBO;
import com.alacriti.ecommerce.dao.OrderDatabase;
import com.alacriti.ecommerce.vo.ProductDetails;

public class OrderBOImpl implements OrderBO{
	Logger log = Logger.getLogger(OrderBOImpl.class.getName());

	OrderDatabase orderDatabase = new OrderDatabase();
	
	public String orderProduct(int productId, int quantity) throws ClassNotFoundException, SQLException{
		return orderDatabase.orderProduct(productId, quantity);
	}
	
	public ArrayList<ProductDetails> showOrders() throws Exception{
		return orderDatabase.showOrders();
	}
}
