package com.alacriti.ecommerce.bo;

import java.sql.SQLException;

public interface ForgotPasswordBO {
	public String forgotPassword(String email, String password) throws ClassNotFoundException, SQLException;
}
