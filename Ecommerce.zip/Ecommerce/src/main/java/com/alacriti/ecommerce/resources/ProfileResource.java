package com.alacriti.ecommerce.resources;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;
import org.jboss.resteasy.plugins.providers.multipart.InputPart;
import org.jboss.resteasy.plugins.providers.multipart.MultipartFormDataInput;

import com.alacriti.ecommerce.delegate.RegistrationDelegete;
import com.alacriti.ecommerce.utility.UserOpenFtl;
import com.alacriti.ecommerce.utility.ViewProfileFtl;
import com.alacriti.ecommerce.vo.Registration;

@Path("/Profile")
public class ProfileResource {
	Logger log = Logger.getLogger(ProfileResource.class.getName());

	@GET
	@Path("viewProfile")
	@Produces(MediaType.TEXT_HTML)
	public String viewProfile() throws Exception{
		ViewProfileFtl viewProfileFtl = new ViewProfileFtl();
		return viewProfileFtl.viewProfile();
	}
	
	
	static String uploadedImage;
	private final String UPLOADED_FILE_PATH = "../../workspaceLuna/Ecommerce/src/main/webapp/ProfileImages/";
	
	@POST
	@Path("/editProfile")
	@Consumes("multipart/form-data")
	public String editProfile(MultipartFormDataInput input) throws Exception, FileNotFoundException{
		
		String fileName = "";
		String imageName = "";
		
		Map<String, List<InputPart>> uploadForm = input.getFormDataMap();
		
		List<InputPart> fnameList = uploadForm.get("exampleInputFirstName");
		 String firstName = fnameList.get(0).getBodyAsString();
		 List<InputPart> lnameList = uploadForm.get("exampleInputLastName");
		 String lastName = lnameList.get(0).getBodyAsString();
		 List<InputPart> emailList = uploadForm.get("exampleInputEmail");
		 String emailId = emailList.get(0).getBodyAsString();
		 List<InputPart> cityList = uploadForm.get("exampleInputCity");
		 String city = cityList.get(0).getBodyAsString();
		 List<InputPart> pincodeList = uploadForm.get("exampleInputPincode");
		 String pin = pincodeList.get(0).getBodyAsString();
		 int pincode = Integer.parseInt(pin);
		 List<InputPart> mobileNumberList = uploadForm.get("exampleInputMobileNumber");
		 String mobileNO = mobileNumberList.get(0).getBodyAsString();
		 long mobileNumber = Long.parseLong(mobileNO);
		 
		 List<InputPart> inputParts = uploadForm.get("fileUpload");
		for (InputPart inputPart : inputParts) {

			try {

				MultivaluedMap<String, String> header = inputPart.getHeaders();
				fileName = getFileName(header);

				//convert the uploaded file to inputstream
				InputStream inputStream = inputPart.getBody(InputStream.class,null);

				byte [] bytes = IOUtils.toByteArray(inputStream);
				
				imageName = fileName;
				//constructs upload file path
				fileName = UPLOADED_FILE_PATH + fileName;
				
				writeFile(bytes,fileName);
				
				uploadedImage=fileName;
				
				log.info("RegistrationResource.uploadImage: Done");

			} catch (IOException e) {
				
				e.printStackTrace();
			}

		}
		

		Registration registration = new Registration(firstName, lastName, emailId, city, pincode, mobileNumber, imageName);
		RegistrationDelegete delegate = new RegistrationDelegete(registration);
		delegate.editProfile();
		UserOpenFtl userOpenFtl = new UserOpenFtl();
		String str = userOpenFtl.userProducts(LoginResource.detailsOfLoginUser);
		
		return str;
		
		
	}

	
	//get uploaded filename, is there a easy way in RESTEasy?
	private String getFileName(MultivaluedMap<String, String> header) {

		String[] contentDisposition = header.getFirst("Content-Disposition").split(";");
		
		for (String filename : contentDisposition) {
			if ((filename.trim().startsWith("filename"))) {

				String[] name = filename.split("=");
				
				String finalFileName = name[1].trim().replaceAll("\"", "");
				return finalFileName;
			}
		}
		return "unknown";
	}

	//save to somewhere
	private void writeFile(byte[] content, String filename) throws IOException {

		File file = new File(filename);

		if (!file.exists()) {
			file.createNewFile();
		}

		FileOutputStream fop = new FileOutputStream(file);

		fop.write(content);
		fop.flush();
		fop.close();

	}
	
}
