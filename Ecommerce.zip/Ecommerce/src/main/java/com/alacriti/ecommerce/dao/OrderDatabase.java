package com.alacriti.ecommerce.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.ListIterator;

import org.apache.log4j.Logger;

import com.alacriti.ecommerce.resources.LoginResource;
import com.alacriti.ecommerce.vo.ProductDetails;

public class OrderDatabase extends DatabaseClass{
	Logger log = Logger.getLogger(OrderDatabase.class.getName());

	public String orderProduct(int productId, int quantity) throws ClassNotFoundException, SQLException{
		Connection con = getConnection();
		Statement st = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);

		String q = "select quantity from prod_dtls_tbl where prodid="+productId;
		ResultSet set = st.executeQuery(q);
		set.next();
		if(quantity > set.getInt(1)){
			return "Sorry! only "+set.getInt(1)+" products are available";
		}
		
		String q1 = "select catg from prod_dtls_tbl  where prodid="+productId;
		ResultSet set1 = st.executeQuery(q1);
		set1.next();
		int catogeyId = set1.getInt(1);
		
		int userId = LoginResource.detailsOfLoginUser.getUserId();
		String q2 = "insert into orders_tbl(userid, product, catg, quantity) values("+userId+", "+productId+", "+catogeyId+", "+quantity+")";
		int n2 = st.executeUpdate(q2);
		
		String q3 = "delete from cart_tbl where userid="+userId+" and product="+productId;
		int n3 = st.executeUpdate(q3);
		log.info("OrderDatabase.orderProduct: records deleted from cart_tbl is "+n3);
		
		String q4 = "update prod_dtls_tbl set quantity=quantity-"+quantity+" where prodid="+productId;
		int n4 = st.executeUpdate(q4);
		log.info("OrderDatabase.orderProduct: quantity is reduced"+n4);
		
		closeConnection(con);
		
		if(n2==1){
			return "Congratulations! you baught the Product from our store";	
		}
		else{
			return "Sorry! please try again";
		}
	}
	
	
	public ArrayList<ProductDetails> showOrders() throws Exception{
		Connection con = getConnection();
		Statement st = con.createStatement();
		
		String q1 = "select product, buydate, quantity from orders_tbl where userid="+LoginResource.detailsOfLoginUser.getUserId();
		ResultSet set1 = st.executeQuery(q1);
		ArrayList<ProductDetails> cortList = new ArrayList<ProductDetails>();
		ArrayList<ProductDetails> prodIdList = new ArrayList<ProductDetails>();
		while(set1.next()){
			prodIdList.add(new ProductDetails(set1.getInt(1), set1.getDate(2), set1.getInt(3)));
		}
		
		
		ListIterator<ProductDetails> itr=prodIdList.listIterator(); 
		while(itr.hasNext()){ 
			ProductDetails details = new ProductDetails();
			details = itr.next();
			String q2 = "select * from prod_dtls_tbl where prodid="+details.getId();
			ResultSet set2 = st.executeQuery(q2);	
		
			while(set2.next()){			
				ProductDetails productDetails = new ProductDetails(set2.getInt(1), set2.getString(2), details.getQuantity(), set2.getDouble(5), "../ProductImgs/"+set2.getString(6), set2.getString(7), details.getDate());
				cortList.add(productDetails);
			}
		}
		closeConnection(con);
		return cortList;
	}

}
