package com.alacriti.ecommerce.bo;

import java.sql.SQLException;

import com.alacriti.ecommerce.vo.PaginationRecordID;

public interface SelectorBO {
	public PaginationRecordID selectorRecordCount(String selector) throws ClassNotFoundException, SQLException;
}
