package com.alacriti.ecommerce.delegate;

import java.sql.SQLException;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.alacriti.ecommerce.bo.impl.CartBOImpl;
import com.alacriti.ecommerce.vo.ProductDetails;

public class CartDelegete {
	Logger log = Logger.getLogger(CartDelegete.class.getName());

	CartBOImpl cartBOImpl = new CartBOImpl();
	
	public String addToCart(int productId, int userId) throws ClassNotFoundException, SQLException{		
		return cartBOImpl.addToCart(productId, userId);
	}
	
	public ArrayList<ProductDetails> showCart() throws ClassNotFoundException, SQLException{
		return cartBOImpl.showCart();
	}
	
	public ArrayList<ProductDetails> buyCartItems() throws ClassNotFoundException, SQLException{
		return cartBOImpl.buyCartItems();
	}
	
	public void removefromCart(int productId) throws ClassNotFoundException, SQLException{
		cartBOImpl.removefromCart(productId);
	}
}
