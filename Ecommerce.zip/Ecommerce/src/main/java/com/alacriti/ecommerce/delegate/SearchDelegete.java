package com.alacriti.ecommerce.delegate;

import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.alacriti.ecommerce.bo.impl.SearchBOImpl;
import com.alacriti.ecommerce.vo.PaginationRecordID;


public class SearchDelegete {
	Logger log = Logger.getLogger(SearchDelegete.class.getName());

	public PaginationRecordID searchRecordCount(String search, String catogery) throws ClassNotFoundException, SQLException{
		log.info("SearchDelegete.searchRecordCount: this is delegete class "+search);
		SearchBOImpl searchBOImpl = new SearchBOImpl();
		return searchBOImpl.searchRecordCount(search, catogery);
	}
}
