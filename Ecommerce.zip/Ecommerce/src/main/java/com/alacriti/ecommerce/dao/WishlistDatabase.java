package com.alacriti.ecommerce.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.alacriti.ecommerce.resources.LoginResource;
import com.alacriti.ecommerce.utility.UserOpenFtl;
import com.alacriti.ecommerce.vo.ProductDetails;
import com.alacriti.ecommerce.vo.Registration;

public class WishlistDatabase extends DatabaseClass{
	Logger log = Logger.getLogger(WishlistDatabase.class.getName());
	
	public String addToWishlist(int productId, int userId) throws ClassNotFoundException, SQLException{
		Connection con = getConnection();
		Statement st = con.createStatement();
		
		String q1 = "select * from wishlist_tbl where product="+productId+" and userid="+userId;
		ResultSet set1 = st.executeQuery(q1);
		if(set1.next()){
			return "You already have this product in your wishlist";
		}
		else{
		
			String q2 = "insert into wishlist_tbl values("+userId+", "+productId+")";
			int n2 = st.executeUpdate(q2);
			Registration data = (Registration) UserOpenFtl.profileMap.get("object");
			data.setWishlistCount(data.getWishlistCount()+1);
			log.info("WishlistDatabase.addToWishlist: wishlit count is: "+data.getWishlistCount());
			
			if(n2 == 1){
				
				closeConnection(con);
				return "Product is added successfully";
			}
			else{
				closeConnection(con);
				return "Product is not added to your cart, please try again";
			}
		}
	}
	
	public ArrayList<ProductDetails> showWishlist() throws ClassNotFoundException, SQLException{
		Connection con = getConnection();
		Statement st = con.createStatement();
		
		String q = "select * from wishlist_tbl";
		ResultSet set = st.executeQuery(q);
		Map<Integer, String> catogeryMap = new HashMap<Integer, String>();
		while(set.next()){
			catogeryMap.put(set.getInt(1), set.getString(2));
		}
		
		String q1 = "select product from wishlist_tbl where userid="+LoginResource.detailsOfLoginUser.getUserId();
		ResultSet set1 = st.executeQuery(q1);
		ArrayList<ProductDetails> cortList = new ArrayList<ProductDetails>();
		ArrayList<Integer> prodIdList = new ArrayList<Integer>();
		while(set1.next()){
			prodIdList.add(set1.getInt(1));
		}
		
		 
		for(int i=0; i<prodIdList.size(); i++){
			String q2 = "select * from prod_dtls_tbl where prodid="+prodIdList.get(i);
			ResultSet set2 = st.executeQuery(q2);	
		
			while(set2.next()){			
				ProductDetails productDetails = new ProductDetails(set2.getInt(1), set2.getString(2), set2.getInt(4), set2.getDouble(5), "../ProductImgs/"+set2.getString(6), set2.getString(7));
				cortList.add(productDetails);
			}
		}
		closeConnection(con);
		return cortList;
		
	}
	
	
	public void removeFromWishlist(int productId) throws ClassNotFoundException, SQLException{
		Connection con = getConnection();
		Statement st = con.createStatement();
		
		Registration user = (Registration) UserOpenFtl.profileMap.get("object");
		String q1 = "delete from wishlist_tbl where product="+productId+" and userid="+user.getUserId();
		int n = st.executeUpdate(q1);
		closeConnection(con);
		if(n==1){
			log.info("WishlistDatabase.removeFromWishlist: record is deleted successfully");
		}
		else{
			log.info("WishlistDatabase.removeFromWishlist: record is not deleted");
		}
	}
}
