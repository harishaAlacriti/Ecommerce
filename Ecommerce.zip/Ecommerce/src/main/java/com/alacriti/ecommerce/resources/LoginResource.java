package com.alacriti.ecommerce.resources;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.Context;

import org.apache.log4j.Logger;

import com.alacriti.ecommerce.dao.LoginDatabase;
import com.alacriti.ecommerce.delegate.LoginDelegete;
import com.alacriti.ecommerce.utility.LoginPageFtl;
import com.alacriti.ecommerce.utility.UserOpenFtl;
import com.alacriti.ecommerce.vo.Registration;

@Path("/login")
public class LoginResource{
	Logger log = Logger.getLogger(LoginResource.class.getName());

	LoginDatabase loginDatabase = new LoginDatabase();
	UserOpenFtl userProfile = new UserOpenFtl();
	@Context HttpServletRequest request;
	public static Registration detailsOfLoginUser;
	
	
	@POST
	public String login(@FormParam("loginInputEmail") String emailId,
			@FormParam("loginInputPassword") String password) throws Exception{

			LoginDelegete delegate = new LoginDelegete(emailId, password);
			detailsOfLoginUser = delegate.loginUser();

			String ftlString = "";
			log.info("LoginResource.login: "+detailsOfLoginUser);
			if(detailsOfLoginUser==null){
				LoginPageFtl loginOpenFtl = new LoginPageFtl();
				
				ftlString = loginOpenFtl.loginPage();
				log.info("LoginResource.login: "+ftlString);
				return ftlString;
			}
			else
			{
				HttpSession session = request.getSession(true);
				log.info("LoginResource.login: "+session);
				session.setAttribute("emailId", emailId);
				session.setAttribute("firstName", detailsOfLoginUser.getFirstName());
				
				UserOpenFtl userOpenFtl = new UserOpenFtl();
				
				if(detailsOfLoginUser.getRole() == 1){
						ftlString = userOpenFtl.userProducts(detailsOfLoginUser);
				}
				else if(detailsOfLoginUser.getRole() == 2){
						ftlString = userOpenFtl.adminProducts(detailsOfLoginUser);
				}	
				return ftlString;
			}
			
	}	
	
	
}
