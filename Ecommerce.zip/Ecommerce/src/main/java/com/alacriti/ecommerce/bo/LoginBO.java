package com.alacriti.ecommerce.bo;

import com.alacriti.ecommerce.vo.Registration;

public interface LoginBO {
	public Registration loginUser(String emailId, String password) throws Exception;
}
