package com.alacriti.ecommerce.bo.impl;

import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.alacriti.ecommerce.bo.RegistrationBO;
import com.alacriti.ecommerce.dao.RegistrationDatabase;
import com.alacriti.ecommerce.vo.Registration;

public class RegistrationBOImpl implements RegistrationBO{
	Logger log = Logger.getLogger(RegistrationBOImpl.class.getName());

	RegistrationDatabase registrationDatabase = new RegistrationDatabase();
	public String registerPerson(Registration registration) throws Exception{
		String str = registrationDatabase.register(registration);
		return str;
		
	}
	public void editProfile(Registration registration) throws ClassNotFoundException, SQLException {
		registrationDatabase.editProfile(registration);
		
	}
}
