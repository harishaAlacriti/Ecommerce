package com.alacriti.ecommerce.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.alacriti.ecommerce.vo.ProductDetails;



public class PaginationDatabase extends DatabaseClass{
	Logger log = Logger.getLogger(PaginationDatabase.class.getName());

	
	public ArrayList<ProductDetails> paginationNext(int start, int size) throws ClassNotFoundException, SQLException{
		Connection con = getConnection();
		Statement st = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
		
		ArrayList<ProductDetails> list = new ArrayList<ProductDetails>();
		if(start!=0 && size!=0){
			String q1 = "select * from prod_dtls_tbl limit "+start+", "+size;
			ResultSet set = st.executeQuery(q1);
			while(set.next()){
				ProductDetails productDetails = new ProductDetails(set.getInt(1),set.getString(2), set.getInt(4),set.getDouble(5), "../ProductImgs/"+set.getString(6), set.getString(7));
				list.add(productDetails);
			}
		}
		else{
			String q1="select * from prod_dtls_tbl limit 0, 6";
			ResultSet set = st.executeQuery(q1);
			while(set.next()){
				
				ProductDetails productDetails = new ProductDetails(set.getInt(1),set.getString(2), set.getInt(4),set.getDouble(5), "../ProductImgs/"+set.getString(6), set.getString(7));
				
				list.add(productDetails);
			}
		}
		
		closeConnection(con);
		return list;
	}

	public String getRecordCount() throws SQLException, ClassNotFoundException{
		Connection con = getConnection();
		Statement st = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);

		String q1="select count(*) from prod_dtls_tbl";
		ResultSet set1 = st.executeQuery(q1);
		set1.next();
		int count = set1.getInt(1);
		set1.close();
	
		closeConnection(con);
		return count+"";
	}
}
