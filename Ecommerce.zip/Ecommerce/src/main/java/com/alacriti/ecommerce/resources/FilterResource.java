package com.alacriti.ecommerce.resources;

import java.sql.SQLException;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;

import com.alacriti.ecommerce.delegate.FilterDelegete;
import com.alacriti.ecommerce.vo.PaginationRecordID;


@Path("/filter")
public class FilterResource {
	Logger log = Logger.getLogger(FilterResource.class.getName());

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public PaginationRecordID filter(@QueryParam("start") int start,
						@QueryParam("end") int end, 
						@QueryParam("catogery") String catogery, 
						@QueryParam("search") String search) throws ClassNotFoundException, SQLException{
		FilterDelegete filterDelegete = new FilterDelegete();
		return filterDelegete.filter(start, end, catogery, search);
	}
}
