package com.alacriti.ecommerce.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.UUID;

import org.apache.log4j.Logger;

import com.alacriti.ecommerce.vo.PaginationRecordID;
import com.alacriti.ecommerce.vo.ProductDetails;

public class SelectorDatabase extends DatabaseClass{
	Logger log = Logger.getLogger(SelectorDatabase.class.getName());

	
	public PaginationRecordID selectorRecordCount(String selector) throws SQLException, ClassNotFoundException{
		Connection con = getConnection();
		Statement st = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);

		String uniqueID = UUID.randomUUID().toString();
		
		ArrayList<ProductDetails> setList = new ArrayList<ProductDetails>();
		String q1 = "select catgid from catg_tbl where catg='"+selector+"'";
		log.info("SelectorDatabase.selectorRecordCount: this is in SelectorDatabase");
		log.info("SelectorDatabase.selectorRecordCount:"+q1);
		ResultSet set1 = st.executeQuery(q1);
		set1.next();
		int catogery = set1.getInt(1);
		
		String q2 = "select * from prod_dtls_tbl where catg="+catogery+" and quantity!=0";
		ResultSet set2 = st.executeQuery(q2);
		while(set2.next()){
			setList.add(new ProductDetails(set2.getInt(1), set2.getString(2), selector, set2.getInt(4), set2.getDouble(5), set2.getString(6), set2.getString(7), set2.getDate(8)));
		}
		set1.close();
		
		
		ProductDetails productDetails = new ProductDetails();
		int j = 1;
		int n3 = 0;
		for(int i=0; i<setList.size(); i++){
			productDetails = setList.get(i);
			String q3 = "insert into pagination_tbl values('"+uniqueID
					+"', "+j
					+", "+productDetails.getId()
					+", '"+productDetails.getProductName()
					+"', '"+productDetails.getCategory()
					+"', "+productDetails.getQuantity()
					+", "+productDetails.getProductPrice()
					+", '"+productDetails.getFileName()
					+"', '"+productDetails.getDescription()
					+"', '"+productDetails.getDate()
					+"')";
			n3 = n3 + st.executeUpdate(q3);
			j++;		
		}
		log.info("SelectorDatabase.selectorRecordCount:records inserted is: "+n3);
		
		int count = setList.size();
		int offset = 6;
		set1.close();
		closeConnection(con);
		
		PaginationRecordID paginationRecordID = new PaginationRecordID(uniqueID, count, offset);
		
		return paginationRecordID;

	}



}
