package com.alacriti.ecommerce.resources;

import java.sql.SQLException;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;

import com.alacriti.ecommerce.delegate.SearchDelegete;
import com.alacriti.ecommerce.vo.PaginationRecordID;

@Path("/search")
public class SearchResource {
	Logger log = Logger.getLogger(SearchResource.class.getName());

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public PaginationRecordID searchRecordCount(@QueryParam("search") String search, @QueryParam("catogery") String catogery) throws ClassNotFoundException, SQLException{
		log.info("SearchResource.searchRecordCount: this is resource class "+search);
		log.info("SearchResource.searchRecordCount: this is resource class "+catogery);
		SearchDelegete searchDelegete = new SearchDelegete();
			return searchDelegete.searchRecordCount(search, catogery);
	}
}
