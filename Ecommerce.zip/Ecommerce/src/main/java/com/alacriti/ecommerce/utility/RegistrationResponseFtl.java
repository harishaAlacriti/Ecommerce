package com.alacriti.ecommerce.utility;

import java.io.OutputStreamWriter;
import java.io.StringWriter;
import java.io.Writer;

import org.apache.log4j.Logger;

import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateExceptionHandler;

public class RegistrationResponseFtl {
	Logger log = Logger.getLogger(RegistrationResponseFtl.class.getName());

	public String loginPage() throws Exception{
		FtlConfiguration ftlConfiguration = new FtlConfiguration();
		Configuration configuration = ftlConfiguration.getConfiguration();
			
		configuration.setTemplateExceptionHandler(TemplateExceptionHandler.RETHROW_HANDLER);
			Template tmp = configuration.getTemplate("login.ftl");
			
			Writer consoleWriter = new OutputStreamWriter(System.out);
			consoleWriter.toString();
			tmp.process(null,consoleWriter);
		
			StringWriter stringWriter = new StringWriter();
	        tmp.process(null, stringWriter);

	        return stringWriter.toString();
			
		}
	
}
