package com.alacriti.ecommerce.bo.impl;

import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.alacriti.ecommerce.bo.SearchBO;
import com.alacriti.ecommerce.dao.SearchDatabase;
import com.alacriti.ecommerce.vo.PaginationRecordID;

public class SearchBOImpl implements SearchBO{
	Logger log = Logger.getLogger(SearchBOImpl.class.getName());

	public PaginationRecordID searchRecordCount(String search, String catogery) throws ClassNotFoundException, SQLException{
		log.info("SearchBOImpl.searchRecordCount: this is boimpl class "+search);
		SearchDatabase searchDatabase = new SearchDatabase();
		return searchDatabase.searchRecordCount(search, catogery);
	}
}
