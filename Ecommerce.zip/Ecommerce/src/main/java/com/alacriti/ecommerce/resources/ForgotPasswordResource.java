package com.alacriti.ecommerce.resources;

import java.sql.SQLException;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;

import org.apache.log4j.Logger;

import com.alacriti.ecommerce.delegate.ForgotPasswordDelegete;
import com.alacriti.ecommerce.utility.GeneratePassword;

@Path("/forgotPassword")
public class ForgotPasswordResource {
	Logger log = Logger.getLogger(ForgotPasswordResource.class.getName());

	@POST
	public void forgotPassword(@QueryParam("email") String email) throws ClassNotFoundException, SQLException{
		String to=email;//change accordingly  
		Properties props = new Properties();  
		 props.put("mail.smtp.host","smtp.gmail.com");  
		 props.put("mail.smtp.socketFactory.port", "465");  
		 props.put("mail.smtp.socketFactory.class",  
		           "javax.net.ssl.SSLSocketFactory");  
		 props.put("mail.smtp.auth", "true");  
		 props.put("mail.smtp.port", "25");  
		 Session session = Session.getDefaultInstance(props,  
				new javax.mail.Authenticator() {  
			 	protected PasswordAuthentication getPasswordAuthentication() {  
			 		return new PasswordAuthentication("harisha1736@gmail.com","9908937721");//change accordingly  
			 	}  
		 });
		 
		 GeneratePassword generatePassword = new GeneratePassword();
		 char[] pass = generatePassword.generatePswd();
		 String password = new String(pass);
		 ForgotPasswordDelegete forgotPasswordDelegete = new ForgotPasswordDelegete();
		 String emailId = forgotPasswordDelegete.forgotPassword(email, password);
		 
		 try {  
			  if(emailId!=null){
				  MimeMessage message = new MimeMessage(session);  
				  message.setFrom(new InternetAddress("harisha1736@gmail.com"));//change accordingly  
				  message.addRecipient(Message.RecipientType.TO,new InternetAddress(to));  
				  message.setSubject("Your new password");  
				  message.setText("your Login credentials are EmailId:: "+emailId+" and Password:: "+password);  
				    
				  //send message  
				  Transport.send(message);  
				 
				  log.info("ForgotPasswordResource.forgotPassword: message sent successfully");  
			  }
			  
		 }catch (MessagingException e) {
			 log.info("ForgotPasswordResource.forgotPassword: "+e);
		}  
	}	
}
