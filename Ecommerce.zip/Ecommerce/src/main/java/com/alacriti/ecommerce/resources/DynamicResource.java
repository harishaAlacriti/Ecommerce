package com.alacriti.ecommerce.resources;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Map;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;
import org.jboss.resteasy.plugins.providers.multipart.InputPart;
import org.jboss.resteasy.plugins.providers.multipart.MultipartFormDataInput;

import com.alacriti.ecommerce.dao.ViewProductDatabase;
import com.alacriti.ecommerce.delegate.AddProductDelegete;
import com.alacriti.ecommerce.utility.AddProductFtl;
import com.alacriti.ecommerce.utility.UserOpenFtl;
import com.alacriti.ecommerce.vo.ProductDetails;


@Path("/")
public class DynamicResource {
	Logger log = Logger.getLogger(DynamicResource.class.getName());
	private final String UPLOADED_FILE_PATH = "../../workspaceLuna/Ecommerce/src/main/webapp/ProductImgs/";
	static String uploadedImage;

	@POST
	@Path("addproduct")
	public String AddProduct(MultipartFormDataInput input) throws Exception{
		
		String fileName = "";
		String imageName = "";
		
		Map<String, List<InputPart>> uploadForm = input.getFormDataMap();
		
		List<InputPart> catogeryList = uploadForm.get("ProductCatogery");
		 String catogery = catogeryList.get(0).getBodyAsString();
		 List<InputPart> productNameList = uploadForm.get("ProductName");
		 String productName = productNameList.get(0).getBodyAsString();
		 List<InputPart> productPriceList = uploadForm.get("ProductPrice");
		 String price = productPriceList.get(0).getBodyAsString();
		 double productPrice = Double.parseDouble(price);
		 List<InputPart> quantityList = uploadForm.get("QuantyOfProducts");
		 String qnty = quantityList.get(0).getBodyAsString();
		 int quantity = Integer.parseInt(qnty);
		 List<InputPart> descriptionList = uploadForm.get("ProductDescription");
		 String description = descriptionList.get(0).getBodyAsString();
		 
		 List<InputPart> inputParts = uploadForm.get("fileUpload");
		 for (InputPart inputPart : inputParts) {
			 try {

					MultivaluedMap<String, String> header = inputPart.getHeaders();
					fileName = getFileName(header);

					//convert the uploaded file to inputstream
					InputStream inputStream = inputPart.getBody(InputStream.class,null);

					byte [] bytes = IOUtils.toByteArray(inputStream);
					
					imageName = fileName;
					//constructs upload file path
					fileName = UPLOADED_FILE_PATH + fileName;
					
					writeFile(bytes,fileName);
					
					uploadedImage=fileName;
					
					log.info("DynamicResource.AddProduct: Done");

				} catch (IOException e) {
					
					e.printStackTrace();
				}

		 }
			ProductDetails productDetails = new ProductDetails(catogery, productName, productPrice, quantity, description, imageName);
			AddProductDelegete add = new AddProductDelegete(productDetails);
			add.addProduct();
				UserOpenFtl userOpenFtl = new UserOpenFtl();
				return userOpenFtl.adminProducts(LoginResource.detailsOfLoginUser);
			
			
		
	}
	
	//get uploaded filename, is there a easy way in RESTEasy?
		private String getFileName(MultivaluedMap<String, String> header) {

			String[] contentDisposition = header.getFirst("Content-Disposition").split(";");
			
			for (String filename : contentDisposition) {
				if ((filename.trim().startsWith("filename"))) {

					String[] name = filename.split("=");
					
					String finalFileName = name[1].trim().replaceAll("\"", "");
					return finalFileName;
				}
			}
			return "unknown";
		}

		//save to somewhere
		private void writeFile(byte[] content, String filename) throws IOException {

			File file = new File(filename);

			if (!file.exists()) {
				file.createNewFile();
			}

			FileOutputStream fop = new FileOutputStream(file);

			fop.write(content);
			fop.flush();
			fop.close();

		}
	
		@POST
		@Path("productAdding")
		public String productView() throws URISyntaxException{
			AddProductFtl addProductFtl = new AddProductFtl();
			return addProductFtl.addProduct(LoginResource.detailsOfLoginUser);
		}
		
		
	
	
	@GET
	@Path("editProduct")
	public Response openProductEditPage() throws URISyntaxException{
		URI uri = new URI("Http://localhost:8080/Ecommerce/EditProduct.html");
		return Response.temporaryRedirect(uri).build();
		
	}
	
	@GET
	@Path("productview")
	@Produces(MediaType.APPLICATION_JSON)	
	public ProductDetails productView(@QueryParam("productId") int productId) throws Exception{
		log.info("DynamicResource.productview: product id id: "+productId);
		ViewProductDatabase viewProductDatabase = new ViewProductDatabase();
		
		ProductDetails productDetails = viewProductDatabase.viewProduct(productId);
		return productDetails;
	}
	
	@GET
	@Path("registerHere")	
	public Response registerHere() throws URISyntaxException{
		URI uri = new URI("../registration.html");
		return Response.temporaryRedirect(uri).build();
	}
	
	@GET
	@Path("homePage")
	public String homePage() throws Exception{
		log.info("Dynamicresource.homePage: This is in home page resource");
		UserOpenFtl userOpenFtl = new UserOpenFtl();
		String str = userOpenFtl.homePage(LoginResource.detailsOfLoginUser);
		
		return str;
	}
}
