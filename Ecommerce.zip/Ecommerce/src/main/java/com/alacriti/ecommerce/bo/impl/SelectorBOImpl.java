package com.alacriti.ecommerce.bo.impl;

import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.alacriti.ecommerce.bo.SelectorBO;
import com.alacriti.ecommerce.dao.SelectorDatabase;
import com.alacriti.ecommerce.vo.PaginationRecordID;

public class SelectorBOImpl implements SelectorBO{
	Logger log = Logger.getLogger(SelectorBOImpl.class.getName());

	SelectorDatabase selectorDatabase = new SelectorDatabase();
	public PaginationRecordID selectorRecordCount(String selector) throws ClassNotFoundException, SQLException{
		return selectorDatabase.selectorRecordCount(selector);
	}
}
