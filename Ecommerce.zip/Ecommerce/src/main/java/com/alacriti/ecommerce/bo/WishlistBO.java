package com.alacriti.ecommerce.bo;

import java.sql.SQLException;
import java.util.ArrayList;

import com.alacriti.ecommerce.vo.ProductDetails;

public interface WishlistBO {
	public String addTowishlist(int productId, int userId) throws ClassNotFoundException, SQLException;
	public ArrayList<ProductDetails> showWishlist() throws ClassNotFoundException, SQLException;
	public void removeFromWishlist(int productId) throws ClassNotFoundException, SQLException;
}
