package com.alacriti.ecommerce.bo;

import java.sql.SQLException;

import com.alacriti.ecommerce.vo.PaginationRecordID;

public interface FilterBO {
	public PaginationRecordID filter(int start, int end, String catogery, String search) throws ClassNotFoundException, SQLException;
}
