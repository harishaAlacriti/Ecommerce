package com.alacriti.ecommerce.bo;

import java.sql.SQLException;
import java.util.ArrayList;

import com.alacriti.ecommerce.vo.ProductDetails;

public interface OrderBO {
	public String orderProduct(int productId, int quantity) throws ClassNotFoundException, SQLException;
	public ArrayList<ProductDetails> showOrders() throws Exception;

}
