package com.alacriti.ecommerce.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;

import com.alacriti.ecommerce.vo.ProductDetails;

public class ViewProductDatabase extends DatabaseClass{
	Logger log = Logger.getLogger(ViewProductDatabase.class.getName());

	public ProductDetails viewProduct(int productId) throws SQLException, ClassNotFoundException{
		Connection con = getConnection();
		Statement st = con.createStatement();
		
		ProductDetails productDetails = null;
		String q1 = "select * from prod_dtls_tbl where prodid="+productId;
		ResultSet set1 = st.executeQuery(q1);
		if(set1.next()){
			productDetails = new ProductDetails(set1.getInt(1), set1.getString(2), set1.getInt(4), set1.getDouble(5), "../ProductImgs/"+set1.getString(6), set1.getString(7));
			closeConnection(con);
			return productDetails;
		}
		else{
			closeConnection(con);
			return productDetails;
		}
	}
}
