package com.alacriti.ecommerce.vo;

import org.apache.log4j.Logger;


public class Registration {
	Logger log = Logger.getLogger(Registration.class.getName());

	private int userId;
	private String firstName;
	private String lastName;
	private String emailId;
	private int role;
	private String password;
	private String city;
	private int pincode;
	private long mobileNumber;
	private String fileName;
	private int cartCount;
	private int wishlistCount;
	 
	  
	public Registration() {
		super();
	}

	public Registration(String firstName, String emailId, String fileName, int role) {
		super();
		this.firstName = firstName;
		this.emailId = emailId;
		this.fileName = fileName;
		this.role = role;
	}

	public Registration(int userId, String firstName, String lastName,
			String emailId, long mobileNumber, String city, int pincode,
		String fileName, int role) {
		super();
		this.userId = userId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailId = emailId;
		this.city = city;
		this.pincode = pincode;
		this.mobileNumber = mobileNumber;
		this.fileName = fileName;
		this.role = role;
	}

	public Registration(String firstName, String lastName, String emailId,
			String password, String city, int pincode, long mobileNumber, String fileName) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailId = emailId;
		this.password = password;
		this.city = city;
		this.pincode = pincode;
		this.mobileNumber = mobileNumber;
		this.fileName = fileName;
	}
	
	
	public Registration(String firstName, String lastName, String emailId,
			String city, int pincode, long mobileNumber, String fileName) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailId = emailId;
		this.city = city;
		this.pincode = pincode;
		this.mobileNumber = mobileNumber;
		this.fileName = fileName;
	}

	public int getRole() {
		return role;
	}

	public void setRole(int role) {
		this.role = role;
	}

	
	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getFirstName() {
		return this.firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return this.lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmailId() {
		return this.emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getCity() {
		return this.city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public int getPincode() {
		return this.pincode;
	}

	public void setPincode(int pincode) {
		this.pincode = pincode;
	}

	public long getMobileNumber() {
		return this.mobileNumber;
	}

	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	
	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public int getCartCount() {
		return cartCount;
	}

	public void setCartCount(int cartCount) {
		this.cartCount = cartCount;
	}

	public int getWishlistCount() {
		return wishlistCount;
	}

	public void setWishlistCount(int wishlistCount) {
		this.wishlistCount = wishlistCount;
	}
	
	
}
