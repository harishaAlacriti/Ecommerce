package com.alacriti.ecommerce.bo.impl;

import java.sql.SQLException;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.alacriti.ecommerce.bo.PaginationBO;
import com.alacriti.ecommerce.dao.PageDb;
import com.alacriti.ecommerce.vo.PaginationRecordID;
import com.alacriti.ecommerce.vo.ProductDetails;

public class PaginationBOImpl implements PaginationBO{
	Logger log = Logger.getLogger(PaginationBOImpl.class.getName());

	PageDb pageDb = new PageDb();

	public PaginationRecordID getRecordCount(String catogery) throws ClassNotFoundException, SQLException{
		return pageDb.getRecordCount(catogery);
	}
	
	
	
	@Override
	public ArrayList<ProductDetails> pagination(int pageNumber, String uniqId, int offset)
			throws ClassNotFoundException, SQLException {
		if(pageNumber==1){
			pageNumber = pageNumber-1;
		}
		else{
			pageNumber=(pageNumber-1)*offset;
		}
		return pageDb.pagination(pageNumber, uniqId, offset);
	}
}
