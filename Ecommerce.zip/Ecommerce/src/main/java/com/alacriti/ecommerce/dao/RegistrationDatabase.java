package com.alacriti.ecommerce.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.apache.log4j.Logger;

import com.alacriti.ecommerce.resources.LoginResource;
import com.alacriti.ecommerce.vo.Registration;


public class RegistrationDatabase extends DatabaseClass{
	Logger log = Logger.getLogger(RegistrationDatabase.class.getName());
	
	public String register(Registration registration) throws Exception{
		int n=0;
		Connection con = getConnection();
		Statement st = con.createStatement();
		try{
			String q1 = "select * from user_dtls_tbl where mailid='"+registration.getEmailId()+"'";
			ResultSet set1 = st.executeQuery(q1);
			if(!set1.next()){
				DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
				Calendar cal = Calendar.getInstance();
				log.info("RegistrationDatabase.register: "+dateFormat.format(cal.getTime()));
				PreparedStatement ps=con.prepareStatement("insert into user_dtls_tbl(firstname, lastname, mailid, password, city, pincode, mobilenum, image, createdon) values(?,?,?,?,?,?,?,?, ?)");  
				ps.setString(1, registration.getFirstName());
				ps.setString(2, registration.getLastName());
				ps.setString(3, registration.getEmailId());
				ps.setString(4, registration.getPassword());
				ps.setString(5, registration.getCity());
				ps.setInt(6, registration.getPincode());
				ps.setLong(7, registration.getMobileNumber());
				ps.setString(8, registration.getFileName());
				ps.setString(9, dateFormat.format(cal.getTime()));
				n = ps.executeUpdate();
				
			}
		}catch(SQLException e){
			log.warn("RegistrationDatabase.register: "+e);
		}
		if(n==1){
			closeConnection(con);
			return "success";
		}
		else{
			closeConnection(con);
			return "This mail id is already registered";
		}
			
	}

	public void editProfile(Registration registration) throws ClassNotFoundException, SQLException {
		Connection con = getConnection();
		Statement st = con.createStatement();
		
		String q1 = "update user_dtls_tbl set firstname='"+registration.getFirstName()
				+"', lastname='"+registration.getLastName()
				+"', mailid='"+registration.getEmailId()
				+"', mobilenum="+registration.getMobileNumber()
				+", city='"+registration.getCity()
				+"', pincode="+registration.getPincode()
				+", image='"+registration.getFileName()
				+"' where mailid='"+LoginResource.detailsOfLoginUser.getEmailId()+"'";
		int n1 = st.executeUpdate(q1);
		log.info("RegistrationDatabase.editProfile: rocords updated are "+n1);
		
	}
	
	
}
