package com.alacriti.ecommerce.resources;

import java.sql.SQLException;
import java.util.ArrayList;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;

import com.alacriti.ecommerce.delegate.CartDelegete;
import com.alacriti.ecommerce.utility.UserOpenFtl;
import com.alacriti.ecommerce.vo.ProductDetails;
import com.alacriti.ecommerce.vo.Registration;


@Path("/Cart")
public class CartResource {
	Logger log = Logger.getLogger(CartResource.class.getName());

	CartDelegete cartDelegete = new CartDelegete();
	
	@POST
	@Path("addToCart/{productId}")
	public String addToCart(@PathParam("productId") int productId) throws ClassNotFoundException, SQLException{
		
		log.info("CartResource.addToCart: proeduct ID is: "+productId);
		
		Registration registration = (Registration) UserOpenFtl.profileMap.get("object");
		log.info("CartResource.addToCart: User ID is: "+registration.getUserId());
		int userId = registration.getUserId();
		return cartDelegete.addToCart(productId, userId);
	}
	
	
	@GET
	@Path("/showCart")
	@Produces(MediaType.APPLICATION_JSON)
	public ArrayList<ProductDetails> showCart() throws Exception{
		ArrayList<ProductDetails> list = cartDelegete.showCart();
		log.info("CartResource.showCart: The list is "+list);
		return list;
//		ShowCartFtl showCartFtl = new ShowCartFtl();
//		return showCartFtl.showCart(list);
	}
	
	@GET
	@Path("/buyCartItems")
	@Produces(MediaType.APPLICATION_JSON)
	public ArrayList<ProductDetails> buyCartItems() throws ClassNotFoundException, SQLException{
		return cartDelegete.buyCartItems();
	}
	
	@POST
	@Path("/removefromCart")
	public void removefromCart(@QueryParam("productId") int productId) throws ClassNotFoundException, SQLException{
		log.info("WishListResource.removeFromWishlist: "+productId);
		cartDelegete.removefromCart(productId);
	}
}
