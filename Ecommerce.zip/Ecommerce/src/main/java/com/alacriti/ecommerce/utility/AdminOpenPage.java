package com.alacriti.ecommerce.utility;

import java.io.OutputStreamWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.alacriti.ecommerce.vo.Registration;

import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateExceptionHandler;

public class AdminOpenPage {
	Logger log = Logger.getLogger(AdminOpenPage.class.getName());

	public static Map<String, Object> profileMap = new HashMap<String, Object>();	Writer consoleWriter = new OutputStreamWriter(System.out);

	public String adminPproducts(Registration detailsOfLoginUser) throws Exception{
		Writer consoleWriter = new OutputStreamWriter(System.out);
		StringWriter stringWriter = new StringWriter();
		
		try{
		FtlConfiguration ftlConfiguration = new FtlConfiguration();
		Configuration configuration = ftlConfiguration.getConfiguration();
		
		configuration.setTemplateExceptionHandler(TemplateExceptionHandler.RETHROW_HANDLER);
		Template tmp = configuration.getTemplate("AdminProductspage.ftl");
		profileMap.put("object", detailsOfLoginUser);
		
		consoleWriter.toString();
		tmp.process(profileMap,consoleWriter);
	
        tmp.process(profileMap, stringWriter);
        }catch(Exception e){
        	log.warn("AdminOpenPage.adminPproducts: "+e);
        }

        return stringWriter.toString();
		
	}
}
