package com.alacriti.ecommerce.utility;

import java.io.OutputStreamWriter;
import java.io.StringWriter;
import java.io.Writer;

import org.apache.log4j.Logger;

import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateExceptionHandler;

public class ViewProfileFtl {
	Logger log = Logger.getLogger(ViewProfileFtl.class.getName());

	Writer consoleWriter = new OutputStreamWriter(System.out);
	StringWriter stringWriter = new StringWriter(); 
	
	public String viewProfile() throws Exception{
		try{
			FtlConfiguration ftlConfiguration = new FtlConfiguration();
			Configuration configuration = ftlConfiguration.getConfiguration();
			
			configuration.setTemplateExceptionHandler(TemplateExceptionHandler.RETHROW_HANDLER);
			Template tmp = configuration.getTemplate("viewProfile.ftl");
			
			consoleWriter.toString();
			tmp.process(UserOpenFtl.profileMap, consoleWriter);
		
	        tmp.process(UserOpenFtl.profileMap, stringWriter);
	    }catch(Exception e){
	    	log.warn("ViewProfileFtl.viewProfile: "+e);
	    }
		return stringWriter.toString();
	}
}
