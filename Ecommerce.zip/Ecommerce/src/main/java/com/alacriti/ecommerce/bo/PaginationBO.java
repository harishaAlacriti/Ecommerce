package com.alacriti.ecommerce.bo;

import java.sql.SQLException;
import java.util.ArrayList;

import com.alacriti.ecommerce.vo.PaginationRecordID;
import com.alacriti.ecommerce.vo.ProductDetails;

public interface PaginationBO {
	public ArrayList<ProductDetails> pagination(int pageNumber, String uniqId, int offset) throws ClassNotFoundException, SQLException;
	public PaginationRecordID getRecordCount(String catogery) throws ClassNotFoundException, SQLException;
}
