package com.alacriti.ecommerce.bo;

import java.sql.SQLException;

import com.alacriti.ecommerce.vo.Registration;

public interface RegistrationBO 
{
	public String registerPerson(Registration registration) throws Exception;
	public void editProfile(Registration registration) throws ClassNotFoundException, SQLException;
}
