package com.alacriti.ecommerce.bo;

import java.sql.SQLException;
import java.util.ArrayList;

import com.alacriti.ecommerce.vo.ProductDetails;

public interface CartBO {
	public String addToCart(int productId, int userId) throws ClassNotFoundException, SQLException;
	public ArrayList<ProductDetails> showCart() throws ClassNotFoundException, SQLException;
	public ArrayList<ProductDetails> buyCartItems()throws ClassNotFoundException, SQLException;
	public void removefromCart(int productId) throws ClassNotFoundException, SQLException;
}
