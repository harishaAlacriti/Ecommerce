package com.alacriti.ecommerce.bo.impl;

import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.alacriti.ecommerce.bo.ForgotPasswordBO;
import com.alacriti.ecommerce.dao.ForgotPasswordDatabase;

public class ForgotPasswordBOImpl implements ForgotPasswordBO{
	Logger log = Logger.getLogger(ForgotPasswordBOImpl.class.getName());

	ForgotPasswordDatabase forgotPasswordDatabase = new ForgotPasswordDatabase();
	public String forgotPassword(String email, String password) throws ClassNotFoundException, SQLException{
		return forgotPasswordDatabase.forgotPassword(email, password);
	}
}
