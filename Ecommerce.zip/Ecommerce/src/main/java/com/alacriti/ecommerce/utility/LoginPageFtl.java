package com.alacriti.ecommerce.utility;

import java.io.OutputStreamWriter;
import java.io.StringWriter;
import java.io.Writer;

import org.apache.log4j.Logger;

import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateExceptionHandler;

public class LoginPageFtl {
	Logger log = Logger.getLogger(LoginPageFtl.class.getName());

		public String loginPage() throws Exception{
			Writer consoleWriter = new OutputStreamWriter(System.out);
			StringWriter stringWriter = new StringWriter();
			try{
			FtlConfiguration ftlConfiguration = new FtlConfiguration();
			Configuration configuration = ftlConfiguration.getConfiguration();
			
			configuration.setTemplateExceptionHandler(TemplateExceptionHandler.RETHROW_HANDLER);
			Template tmp = configuration.getTemplate("login.ftl");
			
			
			consoleWriter.toString();
			tmp.process(null,consoleWriter);
		
	        tmp.process(null, stringWriter);
	        }catch(Exception e){
	        	log.warn("LoginPageFtl.loginPage: "+e);
	        }

	        return stringWriter.toString();
		}
}
