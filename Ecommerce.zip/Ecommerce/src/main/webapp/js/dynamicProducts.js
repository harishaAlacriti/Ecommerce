$(function(){
			$("#header").load("header.html");
			$("#footer").load("footer.html");
			
			var placeholder;
			$('input').focus(function () {
				placeholder = $(this).attr("placeholder");
		        $(this).attr('placeholder', '');
		    });
		    $('input').blur(function () {
		    	console.log("placeholder on blur is "+placeholder);
		        $(this).attr('placeholder', placeholder);
		    });
		    
		    
			$("input").focus(function(){
				$(this).removeAttr("placeholder");
			});
			var catogery = $("#dropdownMenu1").val();
			loadProducts();
			
			
			//////////////////////////////////////////////////////////////
			function loadProducts(){
				$.ajax({
					url: "/Ecommerce/rest/pagination/count?catogery="+catogery,
					type: "GET",
					dataType: "html",
			        success: function(data) 
			        {
			        	var result = $.parseJSON(data);
			        	if($.isEmptyObject(result)==false)
						{
					         console.log(result);
					         $(".pagination").empty();
					         
					         var id = result.uniqID;
					         var count = result.recordCount;
					         var offset=result.offset;
					         console.log("id is "+id);
					         console.log("count is "+count);
					         console.log("offset is "+offset);
					         console.log("catogery is "+catogery);
					         
					         var numberOfPages = count/offset;
					         numberOfPages=Math.ceil(numberOfPages);
					         console.log("Number of pages are: "+numberOfPages);
					         for(var i=1; i<=numberOfPages; i++){
					        	 $(".pagination").append("<li style='display:inline' name="+id+" value="+i+" id="+offset+" class><a>"+i+"</a></li>");					
					         }
					         $(".pagination li:first").addClass("active");
					         var url = "/Ecommerce/rest/pagination/pages?start=1&id="+id+"&offset="+offset
					         productsDisplay(url);   
						}
			        }	
				});
			}
			
			
			 function productsDisplay(url){ 
		         $.ajax({
						url: url,
						type: "GET",
						 dataType: "text",
						success: function(data)
						{
							var result = $.parseJSON(data);
			            	if($.isEmptyObject(result)==false)
							{
			            		console.log("the objects are:");
			            		console.log(result);
			            		for(var j=0;j<result.length;j++)
			            		{
			            			$("#productDiv"+j).removeAttr("hidden");
		 							$("#addToCart"+j).attr("value", result[j].id);
		 							$("#wishList"+j).attr("value", result[j].id);
		 							$("#productImage"+j).attr("src", result[j].fileName).attr("name", result[j].id);
				            		console.log(result[j].fileName);
			            			$("#product"+j).html("<b clas='Capitalize'>"+result[j].productName+"</b>");
				            		$("#price"+j).html("<b>Price:</b> <i>"+result[j].productPrice+"</i>");	
				            		console.log(j+"th object is added");
			            		}
							}
			            }
				});
	        }    
			
			////////////////////////////////////////////////////////////////
			$(".bodyDiv").on("click", "li", function(){ 
				$(".pagination li").removeClass("active");
				$(this).addClass("active");
				
				var pageNumber = $(this).val();
				console.log("This page number is "+pageNumber);
				var uniqid = $(this).attr("name");
				console.log("uniq id is: "+ uniqid);
				var offset = $(this).attr("id");
				console.log("offset is "+offset);
				
				var url = "/Ecommerce/rest/pagination/pages?start="+pageNumber+"&id="+uniqid+"&offset="+offset
				productsDisplay(url);
				
				$(".productDiv").attr("hidden", "hidden");
			});
			
			///////////////////////////////////////////////////////////////
			
			
			//-----------------cartCount----------------------------------//
			$(".bodyDiv").on("click", ".cart", function(){
				console.log($(this).val());
				$.ajax({
					url: "/Ecommerce/rest/Cart/addToCart/"+$(this).val(),
		            type: "POST",
		            success: function(data){
		            	console.log(data);
		            	window.alert(data);
		            	if(data=="Product is added successfully"){
		            		
		            		var count = $("#cartCount").attr("value");
		            		console.log("count before is "+ count);
		            		count = ++count;
		            		console.log("count after is "+ count);
				        	$("#cartCount").text(count);
				        	$("#cartCount").attr("value", count);
		            	}
			         }
				});
			});
			////////////////////////////////////////////////////////////////////	
			$(".bodyDiv").on("click", ".wishlist", function(){
				console.log($(this).val());
				$.ajax({
					url: "../rest/wishList/"+$(this).val(),
			        type: "POST",
			        success: function(data){
			            window.alert(data);
			            if(data=="Product is added successfully"){
				            var count = $("#wishlistCount").attr("value");
				            console.log("count before is "+ count);
				            count = ++count;
				            console.log("count after is "+ count);
				        	$("#wishlistCount").text(count);
				        	$("#wishlistCount").attr("value", count);
			            }
			        }
				});
			});
			//////////////////////////////////////////////////////////////////////
			
		
		$(".productSize").on("click", function(){
			var productid = $(this).attr("name");
			console.log("product id is: "+productid);
			
						
			$.ajax({
				url: "/Ecommerce/rest/productview?productId="+productid,
	            type: "GET",
	            dataType: "html",
	            success: function(data){
	            	var result = $.parseJSON(data);
	            	
		        	if($.isEmptyObject(result)==false)
					{
		        		console.log("The object is "+result);
		        		
		        		$(".modal-body").attr("value", result.id);
		        		$("#productImage").attr("src", result.fileName);
		        		$("#productName b").text(result.productName);
		        		$("#productPrice b").text(result.productPrice);
		        		$("#quantity b").text(result.quantity);
		        		$("#quantity").attr("value", result.quantity);
		        		$("#description b").text(result.description);
	            	
					}
	            	
	            	$("#myModal").modal();
	         
		         }
			});
			
		});
		///////////////////////////////////////////////////////
		
		
		$(".list-group a").click(function(){
			$(".list-group").removeClass("active");
			$(this).addClass("active");
		});
		///////////////////////////////////////////////////////
		
		
		//......................filter.....................//
		$(".bodyDiv").on("click", ".list-group a", function(){
			$("#paginationButtons").empty();
			$(".productDiv").attr("hidden", "hidden");
			$(".list-group a").removeClass("active");
			$(this).addClass("active");
			
			var selector = $("#dropdownMenu1").val();
			var search = $("#searchInput").val();
			var start = $(this).attr("value");
			var end = $(this).attr("id");
			console.log("start is "+start);
			console.log("end is "+end);
			console.log("The selector is "+ selector);
			
			if(search==""){
				var urlPath = "/Ecommerce/rest/filter?start="+start+"&end="+end+"&catogery="+selector;
			}
			else{
				var urlPath =  "/Ecommerce/rest/filter?start="+start+"&end="+end+"&catogery="+selector+"&search="+search;
			}
			
			$.ajax({
				url: urlPath,
				type: "GET",
				dataType: "html",
		        success: function(data) 
		        {
		        	var result = $.parseJSON(data);
		        	if($.isEmptyObject(result)==false)
					{
				         console.log(result);
				         var id = result.uniqID;
				         count = result.recordCount;
				         var offset=result.offset;
				         console.log("id is "+id);
				         console.log("count is "+count);
				         console.log("offset is "+offset);
				         
				         var numberOfPages = count/offset;
				         numberOfPages=Math.ceil(numberOfPages);
				         console.log("Number of pages are: "+numberOfPages);
				         for(var i=1; i<=numberOfPages; i++){
				        	 $(".pagination").append("<li style='display:inline' name="+id+" value="+i+" id="+offset+" class><a>"+i+"</a></li>");					
				         }
				         $(".pagination li:first").addClass("active");
				         var url = "/Ecommerce/rest/pagination/pages?start=1&id="+id+"&offset="+offset;
				         productsDisplay(url);
				     }
		        }	
			});
			
		});
		///////////////////////////////////////////////////////////
		
		//......................selector.....................//
		$("#dropdownMenu1").click(function(){
			$("#paginationButtons").empty();
			$(".productDiv").attr("hidden", "hidden");
			$(".list-group a").removeClass("active");
			$("#searchInput").val("");
			
			var selector = $(this).val();
			console.log("The selector is "+ selector);
			
			$.ajax({
				url: "/Ecommerce/rest/selector?selector="+selector,
				type: "GET",
				dataType: "html",
		        success: function(data) 
		        {
		        	var result = $.parseJSON(data);
		        	if($.isEmptyObject(result)==false)
					{
				         console.log(result);
				         object = result;
				         var id = result.uniqID;
				         count = result.recordCount;
				         var offset=result.offset;
				         console.log("id is "+id);
				         console.log("count is "+count);
				         console.log("offset is "+offset);
				         
				         var numberOfPages = count/offset;
				         numberOfPages=Math.ceil(numberOfPages);
				         console.log("Number of pages are: "+numberOfPages);
				         for(var i=1; i<=numberOfPages; i++){
				        	 $(".pagination").append("<li style='display:inline' name="+id+" value="+i+" id="+offset+" class><a>"+i+"</a></li>");					
				         }
				         $(".pagination li:first").addClass("active");
				         var url = "/Ecommerce/rest/pagination/pages?start=1&id="+id+"&offset="+offset;
				         productsDisplay(url);
					}
		        }	
			});
			
		});
		//////////////////////////////////////////////////////
		
		//......................search.....................//
		$("#search").click(function(){
			$("#paginationButtons").empty();
			$(".productDiv").attr("hidden", "hidden");
			$(".list-group a").removeClass("active");
			
			var searchWord = $("#searchInput").val();
			console.log("search keyword is "+ searchWord);
			var selector = $("#dropdownMenu1").val();
			console.log("The selector is "+ selector);
			
			
		$.ajax({
			url: "/Ecommerce/rest/search?search="+searchWord+"&catogery="+selector,
			type: "GET",
			dataType: "html",
	        success: function(data) 
	        {
	        	var result = $.parseJSON(data);
	        	if($.isEmptyObject(result)==false)
				{
			         console.log(result);
			         object = result;
			         var id = result.uniqID;
			         count = result.recordCount;
			         var offset=result.offset;
			         console.log("id is "+id);
			         console.log("count is "+count);
			         console.log("offset is "+offset);
			         
			         var numberOfPages = count/offset;
			         numberOfPages=Math.ceil(numberOfPages);
			         console.log("Number of pages are: "+numberOfPages);
			         for(var i=1; i<=numberOfPages; i++){
			        	 $(".pagination").append("<li style='display:inline' name="+id+" value="+i+" id="+offset+" class><a>"+i+"</a></li>");					
			         }
			         $(".pagination li:first").addClass("active");
			         var url = "/Ecommerce/rest/pagination/pages?start=1&id="+id+"&offset="+offset;
			         productsDisplay(url);
			    }
	        }	
		});
			
		});
		/////////////////////////////////////////////////////////////////////////
		
		//......................product buy.....................//
		$("#buy").click(function(){
			var productId = $(".modal-body").attr("value");
			var quantity = $("#enterQuantity").val();
			var availQuantity = $("#quantity").attr("value");
			
			console.log("Quantity is: "+quantity);
			console.log("product id is "+productId);
			console.log("availabel quantity is:"+availQuantity);
			
			$.ajax({
				url: "/Ecommerce/rest/order?productId="+productId+"&Quantity="+quantity,
				type: "POST",
				success: function(data){
					alert(data);
					$("#enterQuantity").val("");
					if(availQuantity!=0 && availQuantity>=quantity){
						$("#quantity").attr("value", availQuantity-quantity);
						$("#quantity b").text(availQuantity-quantity);
					}
				}
			});
		});
		
	////////////////////////////////////////////////////////////////////
		
	//------------------showCart-------------------------------------//
		$("#showCart").click(function(){
			$("#navBar").removeClass("active");
			$(this).addClass("active");
			$(".bodyDiv").empty();
			console.log("this is after click");
			$(".bodyDiv").append("<h4 style='align:center;'>Your Cart Items</h4>");
			$(".bodyDiv").append("<table class='table table-striped' id='table'><th><td><b>ProductId</b></td><td><b>Product</b></td><td><b>Availability</b></td><td><b>Price</b></td><td><b>Picture</b></td><td><b>Description</b></td><td></td></th></table>");
			
			$.ajax({
				url: "/Ecommerce/rest/Cart/showCart",
				type: "GET",
				dataType: "html",
				success: function(data){
					console.log("this is after success");
					var result = $.parseJSON(data);
		        	if($.isEmptyObject(result)==false)
					{
		        		
		        		for(var i=0; i<result.length; i++){
		        			$("#table").append("<tr id='"+result[i].id+"'><td></td><td>"+result[i].id+"</td><td>"+result[i].productName+"</td><td>"+result[i].quantity+"</td><td>"+result[i].productPrice+"</td><td><img src='"+result[i].fileName+"' style='max-height:40%; max-width:40%;'></td><td>"+result[i].description+"</td><td><button value='/Ecommerce/rest/Cart/removefromCart?productId="+result[i].id+"' name='cartCount' id="+result[i].id+" class='btn btn-info removeButtom'>remove</button></td></tr>");
		        		}
		        		
		        		
		        		$(".bodyDiv").append("<br/><div class='cartBuy'><button type='button' id='buyCartItems' class='btn btn-success btn-lg col-md-offset-5' style='width: 200px;'>Buy</button></div>");
					}
				}
			});
		});
		
		//////////////////////////////////////////////////////////////////////
		
		//----------------------------showWishList-------------------------//
		$("#showWishlist").click(function(){
			$("#navBar").removeClass("active");
			$(this).addClass("active");
			$(".bodyDiv").empty();
			console.log("this is after click");
			$(".bodyDiv").append("<h4 style='align:center;'>Your Wishlist</h4>");
			$(".bodyDiv").append("<table class='table table-striped' id='table'><th><td><b>ProductId</b></td><td><b>Product</b></td><td><b>Availability</b></td><td><b>Price</b></td><td><b>Picture</b></td><td><b>Description</b></td><td></td></th></table>");
			
			$.ajax({
				url: "/Ecommerce/rest/wishList/showWishlist",
				type: "GET",
				dataType: "html",
				success: function(data){
					console.log("this is after success");
					var result = $.parseJSON(data);
		        	if($.isEmptyObject(result)==false)
					{
		        		for(var i=0; i<result.length; i++){
		        			$("#table").append("<tr id='"+result[i].id+"'><td></td><td>"+result[i].id+"</td><td>"+result[i].productName+"</td><td>"+result[i].quantity+"</td><td>"+result[i].productPrice+"</td><td><img src='"+result[i].fileName+"' style='max-height:40%; max-width:40%;'></td><td>"+result[i].description+"</td><td><button id="+result[i].id+" name='wishlistCount' value='/Ecommerce/rest/wishList/removeFromWishlist?productId="+result[i].id+"' class='btn btn-info removeButtom'>remove</button></form></td></tr>");
		        		}	
					}
				}
			});
		});
		
		//////////////////////////////////////////////////////////////////////////////
		
		//------------------------------showOrders---------------------------------//
		
		$("#showOrders").click(function(){
			$("#navBar").removeClass("active");
			$(this).addClass("active");
			$(".bodyDiv").empty();
			console.log("this is after click");
			$(".bodyDiv").append("<h4 style='align:center;'>Your Orders</h4>");
			$(".bodyDiv").append("<table class='table table-striped' id='table'><th><td><b>Orders</b></td><td><b>ProductId</b></td><td><b>Product</b></td><td><b>Quantity</b></td><td><b>Price</b></td><td><b>Picture</b></td><td><b>Description</b></td><td><b>Total Price</b></td><td><b>Order Date</b></td></th></table>");
			
			$.ajax({
				url: "/Ecommerce/rest/order/showOrders",
				type: "GET",
				dataType: "html",
				success: function(data){
					console.log("this is after success");
					var result = $.parseJSON(data);
		        	if($.isEmptyObject(result)==false)
					{
		        		for(var i=0; i<result.length; i++){
		        			$("#table").append("<tr><td></td><td><b>"+(i+1)+"</b></td><td>"+result[i].id+"</td><td>"+result[i].productName+"</td><td>"+result[i].quantity+"</td><td>"+result[i].productPrice+"</td><td><img src='"+result[i].fileName+"' style='max-height:40%; max-width:40%;'></td><td>"+result[i].description+"</td><td>"+(result[i].quantity * result[i].productPrice)+"</td><td>"+result[i].date+"</tr>");
		        		}
					}
				}
		});
	});
	///////////////////////////////////////////////////////////////////////////
		
	//------------------------------removeProduct----------------------------//
		$(".bodyDiv").on("click", ".removeButtom", function(){
		var productId = $(this).attr("id");
		console.log("product is "+productId);
		$("#"+productId).empty();
		var name = $(this).attr("name");
		console.log("Name is "+ name);
		
		var path = $(this).attr("value");
		console.log("Path is "+path);
		$.ajax({
			url: path,
			type: "POST",
			success: function(data){
				console.log(data);
				var count = $("#"+name).attr("value");
				console.log("count before is "+ count);
				count = --count;
				console.log("count after is "+ count);
				$("#"+name).text(count);
	        	$("#"+name).attr("value", count);
				
			}
		});
	});
	////////////////////////////////////////////////////////////////////
		
	//-------------------------Buy Cart Items---------------------------//
		$(".bodyDiv").on("click", "#buyCartItems", function(){
			$("#changeHere").empty();			
			$.ajax({
				url: "/Ecommerce/rest/Cart/buyCartItems",
				type: "GET",
				dataType: "html",
				success: function(data){
					console.log("this is after success");
					var result = $.parseJSON(data);
		        	if($.isEmptyObject(result)==false)
					{
		        		$(".modal-header").append("<h4 class='modal-title'>Congratulations! You baught these products</h4>")
		    			$("#changeHere").append("<table class='table table-striped' id='tableOfBaughtItems'><th><td></td><td><b>ProductId</b></td><td><b>Product</b></td><td><b>Price</b></td><td><b>Picture</b></td></th></table>");

		        		for(var i=0; i<result.length; i++){
		        			$("#tableOfBaughtItems").append("<tr id='"+result[i].id+"'><td></td><td><b>"+(i+1)+"</b></td><td>"+result[i].id+"</td><td>"+result[i].productName+"</td><td>"+result[i].productPrice+"</td><td><img src='"+result[i].fileName+"' style='max-height:40%; max-width:40%;'></td></tr>");
		        		}
		        		$("#myModal").modal();
		        		$(".bodyDiv").empty();
		        		var count = $("#cartCount").attr("value");
	            		console.log("count before is "+ count);
	            		count = (count-count);
	            		console.log("count after is "+ count);
			        	$("#cartCount").text(count);
			        	$("#cartCount").attr("value", count);
		        		$(".bodyDiv").append("<h4 class='modal-title'>Your Cart is empty</h4>");	
				}
			}
		});
		});
		//////////////////////////////////////////////////////////////////////////////
		
		
		//-------------------------------go home page--------------------------------//
		
		$("#logo").click(function(){
			$(".bodyDiv").empty();
			$.ajax({
				url:"/Ecommerce/rest/homePage",
				type: "GET",
				datatype: "html",
				success: function(data){
					$(".bodyDiv").append(data);
					loadProducts();
				}
				
			
			});
		});
			/*
	  		 });*/
			  
		/////////////////////////////////////////////////////////////////////////////////////   
			
	   //--------------------------------view Profile-------------------------------------//
			  $("#profile, #AddproductSubmit").click(function(){
				 $(".bodyDiv").empty();
				 $.ajax({
						url: "/Ecommerce/rest/Profile/viewProfile",
						type: "GET",
						datatype: "html",
						success: function(data){
							$(".bodyDiv").append(data);
						}
					});
			  });
		//////////////////////////////////////////////////////////////////////////////////
			  
		//-----------------------addProduct--------------------------------------------//
					
					$("#addProduct").click(function(){
						$(".bodyDiv").empty();
						console.log("This is inside");
						
						$.ajax({
							url: "/Ecommerce/rest/productAdding",
							type: "POST",
							datatype: "html",
							success: function(data){
								$(".bodyDiv").append(data);
							}
						});
					});
			
		////////////////////////////////////////////////////////////////////////////////
					
		
		
});